# kingdee-table-query

> 查询金蝶数据库（SQL Server）中指定单据/表的所有有值字段内容，自动区分主表与分录表。
> 当用户提到「查一下XXX单据的信息」「看一下XXX表的数据」「数据库里XXX单据」「在数据库中看XXX」时使用。
> 只要涉及从数据库中查看金蝶业务单据内容，就用此技能。

## 连接配置

已预置连接参数（`sqlserver-db-query` 技能脚本中的配置）：
- 服务器：`fgftyyu53468`
- 数据库：`AIS20230902095713`
- 用户：`sa` / 密码：`112358`
- 驱动：`SQL Server Native Client 11.0`

Python 路径：`C:\Users\Administrator\.workbuddy\binaries\python\versions\3.14.3\python.exe`

## 查询主表（有单据编号时）

### 输入
- `billno`：单据编号（如 `XSDD000287`）
- `table`：表名（如 `T_SAL_ORDER`），根据单据编号反查时可不填

### 步骤

**Step 1**：根据单据编号查出 FID
```python
cur.execute(f"SELECT FID FROM {table} WHERE FBILLNO = '{billno}'").fetchone()[0]
```

**Step 2**：查主表所有有值字段
```python
# 1. 从 INFORMATION_SCHEMA 获取列名，排除二进制类型
col_info = cur.execute("""
    SELECT COLUMN_NAME, DATA_TYPE
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME=? AND DATA_TYPE NOT IN ('image','varbinary','binary')
    ORDER BY ORDINAL_POSITION
""", (table,)).fetchall()

# 2. 动态构建 SELECT（每个字段 CAST 为 NVARCHAR(MAX) 以统一处理）
select_parts = ['CAST(['+r[0]+'] AS NVARCHAR(MAX)) AS c'+str(i) for i,r in enumerate(col_info)]
sql = f"SELECT {','.join(select_parts)} FROM {table} WHERE FID={fid}"
row = cur.execute(sql).fetchone()

# 3. 过滤空值/0/默认值后输出
skip = {'0','0.00','0.00000000','0.0000000000',''}
for i, c in enumerate([r[0] for r in col_info]):
    val = str(row[i]).strip() if row[i] else ''
    if val not in skip and '1900-01-01' not in val:
        print(f'{c}: {val}')
```

## 查询分录表（主表有 FID 后）

### 规律
- 单据分录表名 = 主表名 + `ENTRY`（如 `T_SAL_ORDER` → `T_SAL_ORDERENTRY`）
- 通过 `FID` 关联，`ORDER BY FSEQ`

### 步骤
```python
ecol_info = cur.execute("""
    SELECT COLUMN_NAME, DATA_TYPE
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME=? AND DATA_TYPE NOT IN ('image','varbinary','binary')
    ORDER BY ORDINAL_POSITION
""", (entry_table,)).fetchall()

eselect_parts = ['CAST(['+r[0]+'] AS NVARCHAR(MAX)) AS ec'+str(i) for i,r in enumerate(ecol_info)]
sql = f"SELECT {','.join(eselect_parts)} FROM {entry_table} WHERE FID={fid} ORDER BY FSEQ"
erows = cur.execute(sql).fetchall()

for ri, erow in enumerate(erows):
    print(f'=== 第{ri+1}行 (有值字段) ===')
    for i, c in enumerate([r[0] for r in ecol_info]):
        val = str(erow[i]).strip() if erow[i] else ''
        if val not in skip and '1900-01-01' not in val:
            print(f'  {c}: {val}')
```

## 常见单据表名速查

| 单据 | 主表 | 分录表 |
|------|------|--------|
| 销售订单 | `T_SAL_ORDER` | `T_SAL_ORDERENTRY` |
| 销售出库单 | `T_SD_SALEOUT` | `T_SD_SALEOUTENTRY` |
| 采购订单 | `T_PUR_POORDER` | `T_PUR_POORDERENTRY` |
| 生产订单 | `T_PRD_MOORDER` | `T_PRD_MOORDERENTRY` |
| 物料清单 | `T_ENG_BOM` | `T_ENG_BOMCHILD` |

## 输出格式

先输出主表，再按行输出分录表，每行单独一个分组。
过滤掉以下「假值」：
- `0`、`0.00`、`0.00000000`、`0.0000000000`（数字零）
- `1900-01-01` 系列默认日期
- 空字符串

## 注意事项

- **必须用参数化方式构建 SQL**，避免字符串拼接导致注入风险（但 `fid` 是 INT 可直接拼接，若有顾虑可用 `?` 参数）
- **BOS 字段名 ≠ 数据库列名**：如 BOS 中的 `FEntryNote` 在数据库中是 `FNOTE`
- **image/binary 类型字段跳过**：不能 CAST 为 NVARCHAR，直接排除
- 每次查询完毕 `conn.close()`
