# 金蝶云星空 BOS 设计器参考 — 完整内容

> 来源：FY2023年金蝶云星空_BOS_设计器.pptx
> 共26页

---

## Slide 1 - 封面

**BOS设计器基础**
- 金蝶云星空
- 平台部
- 2023.05

---

## Slide 2 - 目录

01. 标识、字段名、绑定实体属性
02. 值更新与实体服务规则
03. 校验规则
04. 界面布局
05. 数据库相关
06. 许可相关

---

## Slide 3 - 标识、字段名、绑定实体属性

- **标识**：字段控件的标识。通常用于控制元数据的界面显示，控制控件可见性、颜色等效果，也用于表达式取数、插件取数、账表取数。
- **字段名**：数据库中存储的字段名。SQL查询数据库表时、创建数据库视图时会用到。
- **绑定实体属性**：实体数据包的属性名。常用于插件取数。

---

## Slide 4 - 表达式常见问题

**问1：引号如何用？**
答：通常情况下，单引号和双引号都是一样的。内码如果是int、long类型不需要写引号，字符串类型的需要写引号。

**问2：表达式中的空格对表达式是否有影响？**
答：通常情况下，在多个字段之间有多少个空格是没有影响的。字段内部属于一个标识的部分不能有空格，还有引号中的内容，如果包含空格，则认为这是一个整体。

---

## Slide 5 - 文本字段操作

**文本**：标识为 F_Text
- 文本不为空：`F_Text <> null and F_Text <> "" and F_Text <> " "`
- 文本是否包含某值：`F_Text.find("某值") >= 0`
- `F_Text`是否包含`*`：`F_Text.find("*")` → -1（不包含）/ 具体位数（包含，从0开始）
- 切片函数：`F_Text[n:m]`，从n+1到第m位
  - 截取第二到四位：`F_Text[1:4]` → "bcd"
  - 截取字段前四位：`F_Text[:4]` → "abcd"
  - 截取字段后三位：`F_Text[-3:]` → "xyz"
- 文本拆分：`F_Text.split("-")` → `["abcd","xyz"]`
- 去空格：`F_Text.strip()`
- 去掉字符a：`F_Text.strip("a")` → "bcd-xyz"

---

## Slide 6 - 文本字段操作案例

场景：现有字段F_Text，值"ab*12*cd*34"
- 问1：取第一个*之前的数据（ab）
  - `F_Text[:F_Text.find("*")]` 或 `F_Text.split("*")[0]`
- 问2：取最后一个*之后的数据（34）
  - `F_Text[F_Text.rfind("*")+1:]` 或 `F_Text.split("*")[-1]`
- 问3：取第一个*和第二个*中间的数据（12）
  - `F_Text.split("*")[1]`

---

## Slide 7 - 多语言文本

多语言文本：标识为 `F_TPQJ_MulLangText`，绑定实体属性 `F_TPQJ_MulLangTextSTSX`
- 获取当前语言的值，直接取标识 `F_TPQJ_MulLangText` → "中文文本"
- 获取指定语言的值（以英文为例）：
  - `filter(lambda x:x.Key=1033, FBillHead.ActiveObject['F_TPQJ_MulLangTextSTSX'])[0].Value`

表达式拆解：
1. `FBillHead.ActiveObject['F_TPQJ_MulLangTextSTSX']`
2. `filter(lambda x: x.Key=1033, ...)`
3. `[...][0]`

---

## Slide 8 - 日期操作

日期：标识为 `FDate`，另有创建日期 `FCreateDate`
- 日期不为空：`FDate <> null`
- 取日期的年月：`FDate.Year`、`FDate.Month`
- 日期比较：`FDate > FCreateDate`，`FDate.ToString("yyyy-MM-dd") > "2023-05-06"`
- 当前日期：短日期 `@currentshortdate`，长日期 `@currentlongdate`
- 日期计算：
  - 加n小时：`FDate.AddHours(n)`
  - 加n天：`FDate.AddDays(n)`
  - 加n个月：`FDate.AddMonths(n)`
  - 加n年：`FDate.AddYears(n)`
  - n可以是负数，对应减n天等。
- 日期间隔计算：
  - 间隔小时：`(FDate - FCreateDate).TotalHours`
  - 间隔天：`(FDate - FCreateDate).Days`
  - 间隔月：`(FDate.Year - FCreateDate.Year) * 12 + (FDate.Month - FCreateDate.Month)`

**时分对比（忽略日期部分，只比较时间）**：

核心思路：将小时和分钟转为数值（小时数 + 分钟/60），再和目标时间比较。

步骤：
1. 提取小时：`int(str(FDate.ToString('HH')))`
2. 提取分钟：`int(str(FDate.ToString('mm')))`
3. 分钟转小时小数：`分钟 / 60`
4. 相加后和目标时间比较

案例：判断时间是否在 9:30 之后
```
int(str(FDate.ToString('HH'))) + int(str(FDate.ToString('mm'))) / 60 > 9.5
```

- 9.5 表示 9:30（通用公式：`目标小时 + 目标分钟/60`）
- 不推荐字符串比较 `ToString("HH:mm") > "09:30"`，字典序虽通常有效但不严谨
- 不推荐分开判断小时和分钟（如 `Hour > 9 or (Hour == 9 and Minute > 30)`），逻辑复杂易错

---

## Slide 9 - 基础资料操作

基础资料：以物料为例，标识为 `FMaterialId`
- 第一层，能够取到完整数据包，使用标识可以取数
- 第二层，只能取到精简数据包，只能取出来内码Id、编码Number和名称Name

- 不为空：`FMaterialId <> null`
- 内码：`FMaterialId.Id`
- 编码：`FMaterialId.FNumber`
- 名称：`FMaterialId.FName`
- 属性：`FMaterialId.FSpecification`
- 基础资料的基础资料的编码：`FMaterialId.FBaseUnitId.Number`
- 基础资料的基础资料的名称：`FMaterialId.FBaseUnitId.Name.ToString()`
- 分组内码：`FMaterialId.FMaterialGroup.Id`
- 分组编码：`FMaterialId.FMaterialGroup.Number`
- 分组名称：`FMaterialId.FMaterialGroup.Name.ToString()`

---

## Slide 10 - 辅助资料

辅助资料：标识为 `F_TPQJ_Assistant`
- 物料中也有辅助资料：`FMaterialId.F_TPQJ_Assistant`
- 不为空：`F_TPQJ_Assistant <> null`
- 内码：`F_TPQJ_Assistant.Id`
- 编码：`F_TPQJ_Assistant.FNumber`
- 名称：`F_TPQJ_Assistant.FDataValue`

基础资料中的辅助资料：
- 内码：`FMaterialId.F_TPQJ_Assistant.Id`
- 编码：`FMaterialId.F_TPQJ_Assistant.Number`
- 名称：`FMaterialId.F_TPQJ_Assistant.Name`

注意：
- 直接取需要使用标识
- 辅助资料名称的标识是`FDataValue`
- 辅助资料在基础资料中被引用时，名称是`Name`而不是`FDataValue`
- 辅助资料的内码是字符串，因此需要有引号
- 辅助资料不支持二开加自定义字段，平台在很多地方屏蔽了取其他字段。因为辅助资料是免费的、针对简单场景使用的业务对象。如有需求，需要开发基础资料对象实现。

---

## Slide 11 - 数值与下拉列表

**数值**：标识为 `FQty`
- 数值不为空：数值没办法判断为空，默认为0，`FQty <> 0`

**下拉列表**：标识为 `F_TPQJ_Combo`
- 下拉列表不为空：`F_TPQJ_Combo <> null and F_TPQJ_Combo <> "" and F_TPQJ_Combo <> " "`
- 下拉列表的比较和赋值都需要用枚举项值
- 无法通过枚举项名称简单操作（需二开）

---

## Slide 12 - 维度关联字段（弹性域字段）

维度关联字段：辅助属性 `FAuxPropId`、核算维度 `FDetailID`、仓位 `FStockLocId`

`GETFLEXDETAILVALUE(参数1, "参数2", 参数3)`
- 参数1：维度关联字段的标识，如 `FAuxPropId`、`FDetailID`、`FStockLocId`
- 参数2：子维度属性的标识；需要去对应表单获取
  - `BD_FLEXSITEMDETAILV_EXTEND` — 辅助属性维度数据
  - `BD_FLEXITEMDETAILV_EXTEND` — 核算维度数据
  - `BD_FLEXVALUESDETAIL_EXTEND` — 仓位值集维度数据
- 参数3：获取值的类型（1为编码、2为名称，文本类型传1即可）

案例：获取辅助属性中等级的值
`GETFLEXDETAILVALUE(FAuxPropId, "FF100002", 2)`

参考：https://vip.kingdee.com/article/240402217378067712

---

## Slide 13 - Lambda表达式（校验规则）

当物料为"1.01.002"时，校验备注字段唯一性：
```
len(set(map(lambda x:x.FEntryNote, filter(lambda x:x.FMaterialId.FNumber=="1.01.002", FPOOrderEntry)))) = 1
```

执行步骤：
1. 遍历 `FPOOrderEntry`
2. `filter(①)`，过滤FPOOrderEntry中物料编码是1.01.002的分录行
3. `lambda x:x.FEntryNote, ②`。遍历过滤之后的分录行，取FEntryNote字段
4. `map(③)`，将③中取到的字段映射成一个集合
5. `set(④)`，将④中取到的集合中的数据去重
6. `len(⑤)`，计算去重后数据的数量

Lambda表达式相关资料：https://vip.kingdee.com/article/314048924971520000

---

## Slide 14 - Lambda表达式函数示例

**max**：在单据体FEntity的全部分录行中，取日期FDate的最大值
```
max(map(lambda x:x.FDate, FEntity))
```

**min**：在单据体FEntity中，取单据体物料=单据头的物料F_TPQJ_Base的最小单价FPrice
```
min(map(lambda x:x.FPrice, filter(lambda x:x.FMaterialId.FNumber==F_TPQJ_Base.FNumber, FEntity)))
```

**sum**：在单据体FEntity中，将物料分组编码左包含A的物料数量FQty的合计汇总到单据头
```
sum(map(lambda x:x.FQty, filter(lambda x:x.FMaterialId.FMaterialGroup.Number.find("A")==0, FEntity)))
```

**join**：在单据体FEntity中，将所有行的物料名称、对应的采购数量FQty、采购单位FUnitId拼接到一起
```
"+".join(map(lambda x:x.FMaterialId.FName+"("+str(x.FQty)+x.FUnitId.FName+")", FEntity))
```

---

## Slide 15 - 多选基础资料与多选辅助资料

**多选基础资料**：标识为 `F_TPQJ_MulBase`
- 不为空：`len(F_TPQJ_MulBase) > 0`
- 个数：`len(F_TPQJ_MulBase)` → 3
- 内码：`map(lambda x:x.Id, F_TPQJ_MulBase)` → `[102173,104150,102419]`
- 编码：`map(lambda x:x.Number, F_TPQJ_MulBase)` → `["CH4441","CH4448","FY0001"]`
- 名称：`map(lambda x:x.Name.ToString(), F_TPQJ_MulBase)` → `["电脑","切割机","办公用品"]`
- 通过`*`来拼接多个值：`"*".join(map(lambda x:x.Name.ToString(), F_TPQJ_MulBase))` → `"电脑*切割机*办公用品"`

**多选辅助资料**：标识为 `F_TPQJ_MulAssistant`
- 不为空：`len(F_TPQJ_MulAssistant) > 0`
- 个数：`len(F_TPQJ_MulAssistant)` → 2
- 内码：`map(lambda x:x.F_TPQJ_MulAssistant.Id, F_TPQJ_MulAssistant)` → `["46a524cf-5797-4e46-bd0a-7203fc426d9c","6216e8f8eaac27"]`
- 编码：`map(lambda x:x.F_TPQJ_MulAssistant.FNumber, F_TPQJ_MulAssistant)` → `["China","England"]`
- 名称：`map(lambda x:x.F_TPQJ_MulAssistant.FDataValue.ToString(), F_TPQJ_MulAssistant)` → `["中国","英国"]`
- 通过`*`来拼接多个值：`"*".join(map(lambda x:x.F_TPQJ_MulAssistant.FNumber, F_TPQJ_MulAssistant))` → `"China*England"`

---

## Slide 16 - 触发时机

- **值更新**：当前置条件的字段的值发生变化时触发
- **加载**：单据加载时触发
- **新增**：新增时触发
- **行删除**：删除分录时触发
- **行选择**：选择分录行时触发
- **行重置、集合重置**：已被废弃

注意：
- 单据转换不会触发，需要在表单服务策略中实现
- 引入和webapi会触发，可以设置禁用
- 缺省值插件DataChanged事件
- 实体服务规则 ↔ 值更新事件，值更新与实体服务规则之间会彼此触发

---

## Slide 17 - 校验规则-前置条件

前置条件是校验的执行依据。
- 只支持单据头字段（单据合法性校验除外）
- 单据满足条件时，执行整条校验规则。无法针对部分分录行进行校验。
- 单据合法性校验是唯一特殊的校验。

需求：当物料为"1.01"时，校验备注字段唯一性。
设置：通过设置检查分录字段唯一性，前置条件规定物料='1.01'

---

## Slide 18 - 单据合法性校验（按整单校验）

（1）校验单据头的金额FAmount字段大于0
- 校验内容：`FAmount > 0`

（2）当单据类型是标准采购订单时，校验单据体数量字段必录
- 前置条件：`FBillTypeID.FName = "标准采购订单"`
- 校验内容：`FQty > 0`

（3）当单据类型是标准采购订单，并且单据体中存在物料是1.01的行时。校验单据体部分行（物料是1.01的行）的合计数量大于5
- 前置条件：`FBillTypeID.FName = "标准采购订单" and len(filter(lambda x:x.FMaterialId.FNumber=="1.01", FPOOrderEntry)) > 0`
- 校验内容：`sum(map(lambda x:x.FQty, filter(lambda x:x.FMaterialId.FNumber=='1.01', FPOOrderEntry))) > 5`

---

## Slide 19 - 单据合法性校验（按部分行校验）

（1）校验单据体物料是1.01的时候，单据体数量字段必录
- 前置条件：`FMaterialId.FNumber = "1.01"`
- 校验内容：`FQty > 0`

（2）单据类型是标准采购订单，且单据体物料是1.01的时候，单据体备注字段必录
- 前置条件：`FBillTypeID.FName = "标准采购订单" and FMaterialId.FNumber = "1.01"`
- 校验内容：`FEntryNote <> null and FEntryNote <> "" and FEntryNote <> " "`

单据合法性校验的前置条件既是整条检验规则的执行依据，又是校验的适用范围。

---

## Slide 20 - 必录校验设置

| 设置位置 | 单据头字段 | 单据体字段 |
|---------|----------|----------|
| 字段属性必录（视图属性必录） | √ | 单据体有值/必录时，√ |
| 实体服务规则 | √ | ×（仅显示小红点，需另外配置校验规则） |
| 校验规则保存操作 | √ | 单据体有值/必录时，√ |
| 校验规则提交操作 | × | × |

常见问题：
1. 设置了字段必录/校验规则，校验单据体字段必录没生效？
   - 单据体如果是空的，则不会校验字段的必录。单据体需要有值或者单据体必录才会校验。
   - 如果没有关键字段，一行只要有一个字段录入值，则认为有值。
   - 如果有关键字段，只有当前行关键字段录入了值，才认为有值。

2. 提交操作会调用保存操作吗？
   - 单据内，当单据数据有变化时，没有点击保存，直接提交会调用保存。
   - 列表中，因数据没变化，所以不会调用保存。

3. 提交时校验什么时候用？
   - 提交时校验是一个按钮的属性，与提交操作无关，所有按钮都有这个属性。
   - 这是一个前端校验，常用于单据已保存过，直接点提交时，不会调用保存操作，所以不会校验。此时如果提交按钮有勾选"提交时校验"就会校验必录属性和实体服务规则设置的字段必录。

---

## Slide 21 - 界面布局

**面板、页签、分割容器的用法**：
- 面板：一整块内容，字段放进去，随着面板移动
- 页签：数据一页往下翻较多，数据有明显隔离性
- 分割容器：需要分割成不同的块
- 控件的位置都是相对于所属父容器的位置

推荐用法：使用分割容器嵌套页签、面板

**停靠方式**：无停靠、上停靠、下停靠、左停靠、右停靠、充满
- 单据体如果上（下）停靠在面板中，则面板不能使用横向滚动条
- 单据体如果左（右）停靠在面板中，则面板不能使用纵向滚动条
- 单据体本身有滚动条，面板也设置滚动条，前端加载两个无穷大的高度时，会影响性能

---

## Slide 22 - 数据库相关介绍

**常见表的含义**：
- **数据库视图**：查询数据的SQL语句，将选择的基础资料数据合并到一个表中，方便查询。
  - 新建字段：需要手动输入视图名称
  - 修改可选基础资料：需要取消勾选不重建视图，保存。建议修改完成后，勾选不重建视图，避免数据没必要的多次重建。
  - 标准产品的多类别基础资料列表要修改可选基础资料：需要修改视图名，否则升级可能会导致视图重建。

- **多类别基础资料视图的用法**
- **主表**：每一个实体都会有一个表，是数据库中存储的表
- **表_L**：多语言表，表的多语言字段都会存储在多语言表中
- **表_LK**：单据转换的表，记录当前主表与其他表的关联关系
- **拆分表**：为了提高主表的查询性能，将本应该是主表的数据存储到拆分表中

---

## Slide 23 - 许可

**开发许可需求**：
- BOS中开发 → 发布到前台 → 用户打开发布的业务对象 → 用户在单据中F8打开发布的业务对象

**需要许可的情况**：
- 发布到平台现有子系统的单 → 融合开发许可
- 发布到新建的子系统的单 → 独立开发许可

PS：7.x以上的版本简单账表的开发是免费的。独立开发许可包含融合开发许可。

---

## Slide 24 - BOS许可说明

**二开业务对象的许可管控范围**：
- 需要许可：基础资料、单据、万能报表、移动业务对象
- 不需要许可：动态表单、系统参数、简单账表（7.x以上）

基础资料：系统预置5个基础资料对象，免费。（表现为只有编码、名称等基本字段，没有业务逻辑，标准产品不引用）
辅助资料：免费，可以实现简单的自定义基础数据管理，但是限制只有编码、名称、备注字段，不允许增加自定义字段。
注：移动业务对象验证"移动BOS运行平台"，其他的验证"BOS运行平台"

**许可校验方式**：
- 设计器不验证管控
- 运行时打开基础资料、单据、万能报表、移动对象的列表或单据详情界面，验证许可
- 单据上基础资料字段打开F8选择数据界面，不验证许可；但是在F8列表界面继续打开基础资料的详情界面验证许可
- WebAPI调用基础资料、单据时，仅验证该对象所在子系统许可，不验证BOS许可

**融合开发与独立开发**：
- 融合开发：二次开发的内容不需要新增子系统，其二开的单据仅发布在金蝶云星空标准子系统下。验证"融合开发-BOS运行平台"
- 独立开发：二次开发的单据需要发布到自己新增的子系统下。验证"独立开发-BOS运行平台"

---

## Slide 25 - 补充资料（相关帖子链接）

- 界面布局：https://vip.kingdee.com/school/3684?productLineId=1
- BOS知识地图：https://vip.kingdee.com/article/392699482837824512?productLineId=1&isKnowledge=2
- BOS设计器专题：https://vip.kingdee.com/knowledge/specialDetail/363716320510095360?productLineId=1
- 星空开发工程师学习路径-初级：https://vip.kingdee.com/school/learnPath/315173083001044736?productLineId=39
- 金蝶云星空BOS二次开发案例演示：https://vip.kingdee.com/article/94751030918525696?productLineId=1&isKnowledge=2
- 多选基础资料：https://vip.kingdee.com/article/269514594903463168?productLineId=1&isKnowledge=2
- 多选辅助资料：https://vip.kingdee.com/article/269784040616878080?productLineId=1&isKnowledge=2
- Lambda表达式：https://vip.kingdee.com/article/314048924971520000
- 弹性域字段：https://vip.kingdee.com/article/240402217378067712

---

## Slide 26 - （无文本内容）
