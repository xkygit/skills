---
name: kingdee-bos-reference
description: 金蝶云星空 BOS 设计器与BOS平台集成开发参考大全。涵盖BOS设计器表达式语法、校验规则、界面布局、数据库概念、许可说明，以及BOS平台集成开发的产品介绍、业务单据应用、权限控制、文件存储服务器、实体服务规则、业务对象目录、发布与部署等完整内容。当用户询问金蝶、BOS、金蝶云星空、设计器、值更新、校验规则、表达式、BOS平台、集成开发、业务单据、发布部署等话题时自动应用。
---

# 金蝶云星空 BOS 设计器与平台开发参考大全

本技能整合了以下两份核心资料：

1. **BOS设计器参考**（`reference.md`）：来源于 FY2023年金蝶云星空_BOS_设计器.pptx，聚焦表达式语法、校验规则、界面布局、数据库与许可。
2. **BOS平台集成开发帮助文档全集**（`bos-platform-help.md`）：来源于金蝶开放平台官方帮助文档（https://open.kingdee.com/K3Cloud/help/BOS_jckf.html），涵盖BOS平台简介、应用专篇、功能篇、发布与部署等完整操作指南。

---

## 触发条件

当用户提及以下内容时自动应用此技能：
- 金蝶、金蝶云星空、BOS、BOS设计器、BOS平台、集成开发平台
- 表达式、值更新、实体服务规则、校验规则
- 界面布局、面板、页签、分割容器
- 数据库视图、许可、融合开发、独立开发
- 业务单据、单据视图、权限控制、文件存储服务器
- 发布、部署、制作部署包、执行部署
- 基础资料、动态表单、系统参数、弹性字段、列表、简单报表

---

## 资料导航

| 文档 | 内容聚焦 | 适用场景 |
|------|---------|---------|
| [reference.md](reference.md) | BOS设计器表达式、校验规则、界面布局、数据库、许可 | 开发配置、表达式编写、规则设计 |
| [bos-platform-help.md](bos-platform-help.md) | BOS平台产品介绍、操作步骤、发布部署 | 平台使用、业务流程配置、部署实施 |

---

## 核心概念速查（来自 reference.md）

### 标识 vs 字段名 vs 绑定实体属性

| 概念 | 用途 | 使用场景 |
|------|------|----------|
| **标识** | 控件标识，控制元数据界面显示 | 表达式取数、插件取数、账表取数、控制可见性/颜色 |
| **字段名** | 数据库中存储的字段名 | SQL查询、创建数据库视图 |
| **绑定实体属性** | 实体数据包的属性名 | 插件取数 |

### 常用字段表达式速查

**文本（标识如 F_Text）**
- 不为空：`F_Text <> null and F_Text <> "" and F_Text <> " "`
- 包含某值：`F_Text.find("某值") >= 0`
- 切片：`F_Text[n:m]`；前4位 `F_Text[:4]`；后3位 `F_Text[-3:]`
- 拆分：`F_Text.split("-")`
- 去空格：`F_Text.strip()`

**日期（标识如 FDate）**
- 不为空：`FDate <> null`
- 年月：`FDate.Year`、`FDate.Month`
- 比较：`FDate > FCreateDate` 或 `FDate.ToString("yyyy-MM-dd") > "2023-05-06"`
- 当前日期：短日期 `@currentshortdate`，长日期 `@currentlongdate`
- 加减：`FDate.AddDays(n)`、`AddHours(n)`、`AddMonths(n)`、`AddYears(n)`
- 间隔：小时 `(FDate - FCreateDate).TotalHours`，天 `.Days`

**基础资料（以物料 FMaterialId 为例）**
- 不为空：`FMaterialId <> null`
- 内码：`FMaterialId.Id`
- 编码：`FMaterialId.FNumber`
- 名称：`FMaterialId.FName`
- 基础资料的基础资料：`FMaterialId.FBaseUnitId.Number`
- 分组编码：`FMaterialId.FMaterialGroup.Number`
- **注意**：第一层可取完整数据包；第二层只能取 Id/Number/Name

**辅助资料（标识如 F_TPQJ_Assistant）**
- 不为空：`F_TPQJ_Assistant <> null`
- 内码：`F_TPQJ_Assistant.Id`（字符串类型，需引号）
- 编码：`F_TPQJ_Assistant.FNumber`
- 名称：`F_TPQJ_Assistant.FDataValue`
- 在基础资料中被引用时，名称字段是 `Name` 不是 `FDataValue`
- **不支持二开加自定义字段**

**数值（标识如 FQty）**
- 不为空：数值默认0，判断 `FQty <> 0`

**下拉列表（标识如 F_TPQJ_Combo）**
- 不为空：`F_TPQJ_Combo <> null and F_TPQJ_Combo <> "" and F_TPQJ_Combo <> " "`
- 比较和赋值需用**枚举项值**

**多选基础资料（标识如 F_TPQJ_MulBase）**
- 不为空：`len(F_TPQJ_MulBase) > 0`
- 个数：`len(F_TPQJ_MulBase)`
- 编码列表：`map(lambda x:x.Number, F_TPQJ_MulBase)`
- 名称拼接：`"*".join(map(lambda x:x.Name.ToString(), F_TPQJ_MulBase))`

**弹性域字段**
- 取值函数：`GETFLEXDETAILVALUE(维度字段标识, "子维度属性标识", 类型)`
- 类型：1=编码，2=名称
- 案例：`GETFLEXDETAILVALUE(FAuxPropId, "FF100002", 2)`

### Lambda 表达式速查

| 函数 | 示例 | 说明 |
|------|------|------|
| `filter` | `filter(lambda x:x.FNumber=="1.01", FEntity)` | 过滤符合条件的数据行 |
| `map` | `map(lambda x:x.FPrice, FEntity)` | 映射提取指定字段 |
| `set` | `set(map(...))` | 去重 |
| `len` | `len(F_TPQJ_MulBase)` | 计数 |
| `sum` | `sum(map(lambda x:x.FQty, filter(...)))` | 合计 |
| `max` | `max(map(lambda x:x.FDate, FEntity))` | 最大值 |
| `min` | `min(map(lambda x:x.FPrice, filter(...)))` | 最小值 |
| `join` | `"+".join(map(lambda x:x.FName, FEntity))` | 拼接字符串 |

---

## BOS平台集成开发速查（来自 bos-platform-help.md）

### 业务单据配置 19 步总览

| 阶段 | 步骤范围 | 核心动作 |
|------|---------|---------|
| 创建与设计 | 1-6 | 登录平台 → 选择业务对象 → 新建单据 → 拖拽字段 → 编辑属性 → 网络预览 |
| 测试与预览 | 7-9 | 表单预览(F5/F8测试) → 设计视图 → 模板转换 |
| 发布与部署 | 10-12 | 发布到客户端 → 模板部署 → 创建报表模板 |
| 客户端配置 | 13-15 | 配置单据类型 → 开发业务流程 → 通用操作 |
| 功能设置 | 16-19 | 通用查询、选项设置、附件管理、导入导出 |

### 权限控制配置 5 步骤

1. **创建权限对象**：系统管理 → 权限配置化设置 → 权限对象列表 → 新增
2. **配置单据权限控制**：BOS设计器 → 编辑 → 权限控制配置 → 勾选功能/字段权限
3. **发布与查看权限项**：发布到运行台，选择对应权限对象
4. **分配功能权限**：系统管理 → 权限管理 → 业务对象功能权限 → 按角色授权
5. **分配字段权限**：系统管理 → 权限管理 → 字段权限 → 按角色设置查看/编辑权限

### 发布与部署流程

| 环节 | 操作路径 | 关键动作 |
|------|---------|---------|
| 发布到主控台 | 发布 → 发布到主控台 | 选择业务领域/子系统/功能 → 新增明细 → 勾选发布状态 |
| 制作部署包 | 解决方案 → 部署包管理 | 输入包名/路径 → 选择业务对象 → 设置功能部署 → 添加附加文件 |
| 执行部署包 | 双击部署包文件 | 选择目标数据中心 → 自动移植 → 查看安装结果 |

---

## 补充资料

- BOS知识地图：https://vip.kingdee.com/article/392699482837824512
- BOS设计器专题：https://vip.kingdee.com/knowledge/specialDetail/363716320510095360
- 开发工程师学习路径：https://vip.kingdee.com/school/learnPath/315173083001044736
- Lambda表达式详解：https://vip.kingdee.com/article/314048924971520000
- 弹性域字段：https://vip.kingdee.com/article/240402217378067712
