#!/usr/bin/env python3
"""
SQL Server 数据库连接工具
支持：查询、查看表结构、导出 CSV
依赖：pyodbc（首次使用需运行：python -m pip install pyodbc）
"""

import sys
import csv
import json
import argparse
from typing import Any, Optional, Sequence, List, Dict

import pyodbc

# ==================== 数据库连接配置 ====================
# 修改以下配置为你的数据库信息
SERVER = 'fgftyyu53468'
DATABASE = 'AIS20230902095713'
USERNAME = 'sa'
PASSWORD = '112358'
TIMEOUT = 30

# 自动尝试的 ODBC 驱动列表（按优先级）
DRIVERS_TO_TRY = [
    'SQL Server Native Client 11.0',
    'ODBC Driver 17 for SQL Server',
    'ODBC Driver 13 for SQL Server',
    'ODBC Driver 11 for SQL Server',
    'SQL Server',
]


def find_driver():
    """查找系统中可用的 SQL Server ODBC 驱动"""
    try:
        available = [d for d in pyodbc.drivers()]
        for d in DRIVERS_TO_TRY:
            if d in available:
                return d
        if available:
            return available[0]
    except Exception:
        pass
    return None


class Database:
    """数据库连接与操作上下文管理器"""

    def __init__(self, autocommit: bool = False):
        self.conn: Optional[pyodbc.Connection] = None
        self.cursor: Optional[pyodbc.Cursor] = None
        self.autocommit = autocommit

    def __enter__(self) -> 'Database':
        """获取连接和游标"""
        errors = []
        for driver in DRIVERS_TO_TRY:
            try:
                conn_str = (
                    f'DRIVER={{{driver}}};'
                    f'SERVER={SERVER};'
                    f'DATABASE={DATABASE};'
                    f'UID={USERNAME};'
                    f'PWD={PASSWORD};'
                    f'Timeout={TIMEOUT};'
                )
                self.conn = pyodbc.connect(conn_str, autocommit=self.autocommit)
                self.cursor = self.conn.cursor()
                return self
            except pyodbc.Error as e:
                errors.append(f'{driver}: {e}')
                continue
        raise ConnectionError(f'无法连接到数据库，已尝试所有驱动:\n' + '\n'.join(errors))

    def __exit__(self, exc_type, exc_val, exc_tb):
        """安全释放资源"""
        if self.cursor:
            try:
                self.cursor.close()
            except Exception:
                pass
        if self.conn:
            try:
                if not self.autocommit:
                    self.conn.rollback()  # 未提交的事务回滚
                self.conn.close()
            except Exception:
                pass
        return False  # 不抑制异常

    def execute(self, sql: str, params: Optional[Sequence[Any]] = None) -> pyodbc.Cursor:
        """执行 SQL，支持参数化"""
        if params:
            self.cursor.execute(sql, params)
        else:
            self.cursor.execute(sql)
        return self.cursor

    def commit(self):
        """手动提交"""
        if self.conn:
            self.conn.commit()


def execute_query(sql: str, params: Optional[Sequence[Any]] = None,
                  fetch: bool = True) -> Any:
    """
    执行 SQL 查询并返回结果
    :param sql: SQL 语句
    :param params: 参数列表（防注入，无参数时可省略）
    :param fetch: 是否获取结果
    :return: 查询结果列表（每条记录为字典）或影响行数
    """
    with Database() as db:
        cursor = db.execute(sql, params)
        if fetch and cursor.description:
            columns = [col[0] for col in cursor.description]
            rows = cursor.fetchall()
            return [dict(zip(columns, row)) for row in rows]
        else:
            db.commit()
            return cursor.rowcount


def get_tables() -> List[Dict[str, Any]]:
    """获取数据库中所有用户表"""
    sql = """
        SELECT TABLE_SCHEMA, TABLE_NAME
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_TYPE = 'BASE TABLE'
        ORDER BY TABLE_SCHEMA, TABLE_NAME
    """
    return execute_query(sql)


def get_table_schema(table_name: str) -> List[Dict[str, Any]]:
    """获取指定表的结构信息"""
    sql = """
        SELECT
            COLUMN_NAME,
            DATA_TYPE,
            CHARACTER_MAXIMUM_LENGTH,
            IS_NULLABLE,
            COLUMN_DEFAULT
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_NAME = ?
        ORDER BY ORDINAL_POSITION
    """
    return execute_query(sql, [table_name])


def export_to_csv(sql: str, filepath: str, params: Optional[Sequence[Any]] = None,
                  batch_size: int = 1000):
    """将查询结果流式导出为 CSV 文件"""
    with Database() as db:
        cursor = db.execute(sql, params)
        columns = [col[0] for col in cursor.description]

        with open(filepath, 'w', newline='', encoding='utf-8-sig') as f:
            writer = csv.writer(f)
            writer.writerow(columns)

            row_count = 0
            while True:
                rows = cursor.fetchmany(batch_size)
                if not rows:
                    break
                writer.writerows(rows)
                row_count += len(rows)

        print(f"导出完成: {filepath}，共 {row_count} 行")


# ==================== CLI 界面部分 ====================

def print_table(data: Any, max_width: int = 120):
    """在控制台以表格形式打印结果"""
    if not data:
        print("(无数据)")
        return

    if isinstance(data, dict) and "affected_rows" in data:
        print(f"影响行数：{data['affected_rows']}")
        return

    keys = list(data[0].keys())
    # 计算每列最大宽度
    widths = {k: len(str(k)) for k in keys}
    for row in data[:100]:
        for k in keys:
            widths[k] = max(widths[k], len(str(row.get(k, ""))))

    # 限制总宽度
    total = sum(widths.values()) + len(keys) * 3 + 1
    if total > max_width:
        scale = max_width / total
        for k in keys:
            widths[k] = max(8, int(widths[k] * scale))

    def fmt(v: Any, width: int) -> str:
        s = str(v) if v is not None else "NULL"
        if len(s) > width:
            s = s[:width - 3] + "..."
        return s.ljust(width)

    sep = "+" + "+".join("-" * (widths[k] + 2) for k in keys) + "+"
    header = "| " + " | ".join(fmt(k, widths[k]) for k in keys) + " |"

    print(sep)
    print(header)
    print(sep)
    for row in data[:100]:
        line = "| " + " | ".join(fmt(row.get(k), widths[k]) for k in keys) + " |"
        print(line)
    print(sep)

    if len(data) > 100:
        print(f"(仅显示前 100 行，共 {len(data)} 行)")


def main():
    parser = argparse.ArgumentParser(description="SQL Server 数据库查询工具")
    parser.add_argument("-q", "--query", help="执行 SQL 查询")
    parser.add_argument("-t", "--tables", action="store_true", help="列出所有表")
    parser.add_argument("-s", "--schema", help="查看指定表的结构")
    parser.add_argument("-e", "--export", help="将查询结果导出为 CSV 文件路径")
    parser.add_argument("--json", action="store_true", help="以 JSON 格式输出")
    parser.add_argument("--no-table", action="store_true", help="不使用表格形式打印")

    args = parser.parse_args()

    try:
        if args.tables:
            result = get_tables()
            print_table(result)

        elif args.schema:
            result = get_table_schema(args.schema)
            if not result:
                print(f"表 {args.schema} 不存在或没有列信息")
            else:
                print_table(result)

        elif args.query:
            result = execute_query(args.query)
            if args.export:
                # 使用流式导出
                export_to_csv(args.query, args.export)
            elif args.json:
                print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
            elif args.no_table:
                for row in result:
                    print(row)
            else:
                print_table(result)

        elif args.export and not args.query:
            print("错误：使用 -e 导出时必须同时提供 -q SQL 语句")
            sys.exit(1)

        else:
            parser.print_help()

    except pyodbc.Error as e:
        print(f"数据库错误：{e}")
        sys.exit(1)
    except Exception as e:
        print(f"错误：{e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
