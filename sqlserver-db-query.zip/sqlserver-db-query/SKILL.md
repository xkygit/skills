---
name: sqlserver-db-query
description: Connect to local SQL Server databases and execute queries, list tables, view schemas, or export results to CSV. Use when the user needs to query SQL Server, connect to a Kingdee/AIS ERP database, run SQL statements, inspect table structures, or export data from SQL Server.
---

# SQL Server Database Query Tool

A self-contained Python script for connecting to SQL Server databases and performing common operations without external dependencies beyond `pyodbc`.

## Prerequisites

1. **Python 3** installed
2. **pyodbc** package: `python -m pip install pyodbc`
3. An **ODBC driver for SQL Server** installed on the system (e.g., SQL Server Native Client 11.0, ODBC Driver 17 for SQL Server, ODBC Driver 11 for SQL Server)

## Setup

Edit the configuration section at the top of `scripts/sqlserver_connector.py`:

```python
SERVER = 'your-server-name'
DATABASE = 'your-database-name'
USERNAME = 'your-username'
PASSWORD = 'your-password'
```

## Usage

Run the script from the command line:

```bash
python scripts/sqlserver_connector.py [options]
```

### Commands

**List all tables:**
```bash
python scripts/sqlserver_connector.py -t
```

**View table schema:**
```bash
python scripts/sqlserver_connector.py -s T_BD_MATERIAL
```

**Execute a query:**
```bash
python scripts/sqlserver_connector.py -q "SELECT TOP 10 * FROM T_BD_MATERIAL"
```

**Export query results to CSV:**
```bash
python scripts/sqlserver_connector.py -q "SELECT * FROM T_BD_MATERIAL" -e output.csv
```

**Output as JSON:**
```bash
python scripts/sqlserver_connector.py -q "SELECT TOP 5 * FROM T_BD_MATERIAL" --json
```

## For Agent Use

When the user asks to connect to SQL Server, query a database, inspect table structures, or export data:

1. Check if `pyodbc` is available. If not, install it.
2. Use the connector script at `scripts/sqlserver_connector.py`.
3. If the user provides connection details, update the config section at the top of the script before running.
4. For quick queries, run the script with `-q` and capture output.
5. For large result sets, use `-e` to export to CSV instead of printing to console.
