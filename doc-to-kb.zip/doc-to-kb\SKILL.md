---
name: doc-to-kb
description: |
  将 Word(.docx)、PPT(.pptx)、Excel(.xlsx)、PDF(.pdf) 文件批量转换为结构化 Markdown 知识库。
  触发词：整理文件、整理文档、构建知识库、文档转Markdown、知识库构建。
  适用场景：(1) 批量文档格式转换 (2) 为 RAG/向量检索准备语料 (3) 文档归档与索引 (4) 从办公文档提取结构化文本和图片描述。
  核心能力：三级缓存避免重复计算、图片智能抽样识别（防积分爆炸）、自动去重和质量清洗、YAML元数据增强、自动索引生成。
---

# 文档整理 → Markdown 知识库构建

将指定文件夹内所有 Word/PPT/Excel/PDF 文件转化为带元数据的结构化 Markdown 知识库。

## 快速开始

用户说"整理文件"即触发，按以下规则执行：

- **源路径**：用户指定，未指定则用 `./input`
- **输出路径**：用户指定，未指定则用 `./output`
- **路径冲突**：输出已存在时提示用户（覆盖/合并/新路径）
- **不调外部 API**：所有图片识别用内置视觉模型，不需要 ZHIPU_API_KEY

## 核心流程（8 步，不可跳过）

```
步骤1(环境) → 步骤2(路径) → 步骤3(转换) → 步骤4(清洗) → 步骤5(图片) → 步骤6(元数据) → 步骤7(索引) → 步骤8(报告)
```

**积分控制核心在步骤5**——图片识别是积分大头，必须遵守三步优化。

---

## 步骤1：环境准备

```bash
pip install -r scripts/kb_requirements.txt
```

⚠️ 不要用 `markitdown`——它总是缺可选依赖（[pdf]/[docx]/[xlsx]），直接用 Python 原生库。

所需依赖：`python-docx openpyxl python-pptx pymupdf Pillow imagehash pyyaml`

## 步骤2：路径确认与状态初始化

1. 确认源目录和输出目录
2. 输出已存在且非空 → 提示用户：覆盖 / 合并（增量） / 指定新路径
3. 初始化输出结构：

```
output/
├── .kb_state.json          # 处理状态
├── .kb_cache/
│   ├── convert/            # 转换缓存 {file_md5}.md
│   ├── images/             # 图片描述缓存 {filename}.json
│   └── summary/            # 摘要缓存
└── media/                  # 提取的图片
```

状态文件结构 (.kb_state.json)：
```json
{
  "last_run": "ISO时间戳",
  "files": {
    "源文件名.docx": {
      "status": "pending",
      "output": "output/目标.md",
      "file_hash": "md5值",
      "images_total": 0,
      "images_described": 0,
      "error": null
    }
  }
}
```

增量模式：加载已有状态，仅处理 `file_hash` 变更或 `status ≠ completed` 的文件。

## 步骤3：批量转换

运行 `scripts/kb_converter.py`：

```bash
python scripts/kb_converter.py --source ./input --output ./output
```

**各格式转换规则：**

| 格式 | 库 | 规则 |
|------|-----|------|
| DOCX | python-docx | 段落+表格提取，按 style name 判断标题层级 |
| PPTX | python-pptx | 逐幻灯片，`---` 分隔，备注追加 `> 🎤 **演讲备注**` |
| XLSX | openpyxl | 逐 Sheet，`## Sheet: 名称` 分隔，示例前10行 |
| PDF | pymupdf | 逐页，`<!-- Page N -->` 标记，图片导出 media/ |

**缓存**：计算源文件 MD5 → `.kb_cache/convert/{md5}.md`，命中直接复用，跳过转换。

## 步骤4：质量清洗

对每个 .md 自动执行：
- 压缩 ≥3 个连续空行为 2 个
- 删除 Unicode 控制字符（`\x00-\x08`, `\x0b-\x0c`, `\x0e-\x1f`）
- PDF 图片型（文本 <50 字 + 有图片）→ 标记 `ocr_needed: true`
- XLSX 列数 >8 → 表格上方插入总结段落

## 步骤5：图片智能处理 ⭐积分控制关键

**严禁逐张全量调用视觉模型——这是积分暴涨的主因。**

### 5.1 预筛选（运行脚本，零模型调用）

```bash
python scripts/kb_image_process.py --media ./output/media --cache ./output/.kb_cache/images
```

自动执行：
- 文件 <30KB 或 分辨率 <400×300 → 标记 `[装饰图]`，跳过
- 计算 pHash，汉明距离 <5 → 标记 `[重复图]`，复用描述
- 输出 `.image_todo.json`（待描述清单）+ 装饰/重复图的缓存文件

### 5.2 视觉识别（Agent 手动执行）

拿到 `.image_todo.json` 后，按以下规则用内置 `image` 工具描述：

**三步省积法：**

1. **抽样聚类**：来自同一文档的同质化截图，只取 1-2 张代表图，描述全村复用
2. **批量调用**：每次 ≤10 张，一次性传入 `image` 工具的 `images` 参数
3. **压缩传输**：图片先复制到 workspace（`image` 工具沙箱限制），大图建议先 resize 到 ~1024px 宽

**提示词模板（单批多图）：**

```
请对这N张截图分别用一句话中文简要描述每张图的内容和关键信息。
按顺序编号1-N输出，格式：N: 描述内容。
这些是[文档主题]的[文档类型]截图。
```

### 5.3 缓存写入

每批识别结果立即写入 `.kb_cache/images/{filename}.json`：

```json
{
  "source_file": "图片名.png",
  "description": "描述内容",
  "desc_type": "detailed",
  "model": "built-in-vision",
  "cached_at": "ISO时间戳"
}
```

## 步骤6：元数据增强 + 步骤7：索引构建

```bash
python scripts/kb_finalizer.py --output ./output
```

自动完成：
- 每个 .md 顶部注入 YAML Front Matter（source_file, doc_type, images_total, images_described, summary）
- 将图片描述注入到对应 `![](media/xxx.png)` 引用下方
- 生成文档级智能摘要（取前500字 + 标题首段）
- 生成 `output/index.md`（按文档类型分组，含链接和统计）

**YAML Front Matter 格式：**
```yaml
---
source_file: "原始文件名.pdf"
source_path: "input/原始文件名.pdf"
doc_type: "pdf"
images_total: 128
images_described: 52
images_decorative: 76
summary: "PDF文档，介绍金蝶云星空采购暂估3种业务流程及账务处理方法..."
created_date: "2026-05-21"
kb_version: "1.0"
---
```

## 步骤8：最终报告

输出格式：

```
============================================================
✅ 知识库构建完成报告
============================================================

### 处理统计
| 类型 | 文件数 | 总图片 | 已描述 | 装饰图 |
|------|--------|--------|--------|--------|

### 🖼️ 图片处理
- 总提取 X 张 → 预筛选排除 Y 张 → AI描述 Z 张

### 📂 输出路径
- 知识库根目录 / 索引文件 / 状态文件 / 缓存目录

### 🚀 后续指引
1. 向量化：对 output 下所有 .md 分块生成向量
2. 增量更新：新文件放入源目录重新运行
3. 缓存清理：.kb_cache/ 可手动清理

### ⚠️ 异常记录
- 列出所有失败文件和原因
```

---

## 关键坑点速查

| 坑点 | 解决方案 |
|------|---------|
| markitdown 缺 [pdf]/[docx]/[xlsx] 依赖 | 直接用 python-docx/openpyxl/python-pptx/pymupdf |
| `image` 工具沙箱限制无法访问外部路径 | 图片先 `cp` 到 workspace 再传入 |
| PowerShell 不支持 `&&`/`||` | 用 `;` 分行或全写在 Python 脚本 |
| 图片全量识别积分爆炸 | 预筛选 + pHash去重 + 抽样聚类 + 批量调用 |
| Windows 中文路径编码 | Python 用 `encoding='utf-8'`，shell 设 `PYTHONIOENCODING=utf-8` |

---

## 脚本说明

所有脚本放在 `scripts/` 目录下，可独立运行：

### kb_converter.py — 步骤3（文档转换）
```bash
python scripts/kb_converter.py --source ./input --output ./output
```
功能：扫描 → 转换 → 清洗 → 写缓存 → 更新状态

### kb_image_process.py — 步骤5.1（图片预筛选）
```bash
python scripts/kb_image_process.py --media ./output/media --cache ./output/.kb_cache/images
```
功能：计算尺寸/phash → 过滤装饰图/重复图 → 输出 .image_todo.json

### kb_finalizer.py — 步骤6-7（收尾）
```bash
python scripts/kb_finalizer.py --output ./output
```
功能：注入图片描述 → 添加 YAML 元数据 → 生成摘要 → 构建 index.md

### 完整流程
```bash
# 1. 安装依赖
pip install -r scripts/kb_requirements.txt

# 2. 转换文档
python scripts/kb_converter.py --source ./input --output ./output

# 3. 预筛选图片
python scripts/kb_image_process.py --media ./output/media --cache ./output/.kb_cache/images

# 4. 用内置视觉模型描述图片（Agent 执行）
#    读取 .image_todo.json，复制图片到 workspace，批量调用 image 工具

# 5. 收尾
python scripts/kb_finalizer.py --output ./output
```
