# -*- coding: utf-8 -*-
"""
文档批量转换（DOCX/PPTX/XLSX/PDF → Markdown）
用法: python kb_converter.py --source ./input --output ./output
"""
import os, sys, json, hashlib, re, argparse
from pathlib import Path
from datetime import datetime

def file_md5(filepath):
    h = hashlib.md5()
    with open(filepath, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()

def clean_markdown(content):
    content = re.sub(r'\n{4,}', '\n\n\n', content)
    content = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', content)
    return content.strip()

def load_state(output_dir):
    sf = os.path.join(output_dir, ".kb_state.json")
    if os.path.exists(sf):
        with open(sf, 'r', encoding='utf-8-sig') as f:
            return json.load(f)
    return {"last_run": "", "files": {}}

def save_state(state, output_dir):
    state["last_run"] = datetime.now().isoformat()
    with open(os.path.join(output_dir, ".kb_state.json"), 'w', encoding='utf-8') as f:
        json.dump(state, f, ensure_ascii=False, indent=2)

def convert_docx(filepath, output_path, media_dir):
    from docx import Document
    doc = Document(filepath)
    lines = []
    for para in doc.paragraphs:
        text = para.text.strip()
        if not text:
            continue
        sn = para.style.name if para.style else ''
        if sn.startswith('Heading') or sn.startswith('Title'):
            try:
                level = min(int(''.join(filter(str.isdigit, sn)) or 1), 6)
            except:
                level = 1
            lines.append('#' * level + ' ' + text)
        else:
            lines.append(text)
    for table in doc.tables:
        rows_data = [[cell.text.strip() for cell in row.cells] for row in table.rows]
        if rows_data:
            lines.append('\n| ' + ' | '.join(rows_data[0]) + ' |')
            lines.append('| ' + ' | '.join(['---'] * len(rows_data[0])) + ' |')
            for rd in rows_data[1:]:
                lines.append('| ' + ' | '.join(rd) + ' |')
    img_count = 0
    for i, rel in enumerate(doc.part.rels.values()):
        if "image" in rel.target_ref:
            try:
                img_data = rel.target_part.blob
                ext = os.path.splitext(rel.target_ref)[1] or '.png'
                img_name = f"{Path(filepath).stem}_img{i+1}{ext}"
                with open(os.path.join(media_dir, img_name), 'wb') as f:
                    f.write(img_data)
                lines.append(f"\n![{img_name}](media/{img_name})\n")
                img_count += 1
            except:
                pass
    content = '\n'.join(lines)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(content)
    return {"images_total": img_count}

def convert_pptx(filepath, output_path, media_dir):
    from pptx import Presentation
    prs = Presentation(filepath)
    slides = []
    total_imgs = 0
    for sn, slide in enumerate(prs.slides, 1):
        title = slide.shapes.title.text.strip() if slide.shapes.title and slide.shapes.title.text.strip() else f"\u5e7b\u706f\u7247 {sn}"
        slide_lines = [f"---\n\n## {title}"]
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    t = para.text.strip()
                    if t:
                        slide_lines.append(f"{'  ' * (para.level + 1)}- {t}")
            if shape.has_table:
                rows_data = [[cell.text.strip() for cell in row.cells] for row in shape.table.rows]
                if rows_data:
                    slide_lines.append('\n| ' + ' | '.join(rows_data[0]) + ' |')
                    slide_lines.append('| ' + ' | '.join(['---'] * len(rows_data[0])) + ' |')
                    for rd in rows_data[1:]:
                        slide_lines.append('| ' + ' | '.join(rd) + ' |')
            if shape.shape_type == 13:
                try:
                    image = shape.image
                    img_name = f"{Path(filepath).stem}_s{sn}_{total_imgs+1}.{image.ext}"
                    with open(os.path.join(media_dir, img_name), 'wb') as f:
                        f.write(image.blob)
                    slide_lines.append(f"\n![\u5e7b\u706f\u7247{sn}\u56fe\u7247{total_imgs+1}](media/{img_name})\n")
                    total_imgs += 1
                except:
                    pass
        if slide.has_notes_slide and slide.notes_slide.notes_text_frame.text.strip():
            slide_lines.append(f'\n> \ud83c\udfa4 **\u6f14\u8bb2\u5907\u6ce8**\uff1a{slide.notes_slide.notes_text_frame.text.strip()}')
        slides.append('\n'.join(slide_lines))
    content = '\n\n'.join(slides)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(content)
    return {"images_total": total_imgs}

def convert_xlsx(filepath, output_path, media_dir):
    import openpyxl
    wb = openpyxl.load_workbook(filepath, data_only=True)
    sheets = []
    for sname in wb.sheetnames:
        sheet = wb[sname]
        sheet_lines = [f"## Sheet: {sname}", ""]
        rows_data = [[str(c.value).strip() if c.value is not None else '' for c in row] for row in sheet.iter_rows(values_only=False)]
        if rows_data:
            col_count = len(rows_data[0])
            if col_count > 8:
                sheet_lines.append(f"**\u8868\u683c\u6982\u8981**\uff1a{len(rows_data)-1} \u884c \u00d7 {col_count} \u5217\u3002")
            sheet_lines.append('| ' + ' | '.join(rows_data[0]) + ' |')
            sheet_lines.append('| ' + ' | '.join(['---'] * col_count) + ' |')
            limit = min(len(rows_data)-1, 10)
            for rd in rows_data[1:1+limit]:
                while len(rd) < col_count:
                    rd.append('')
                sheet_lines.append('| ' + ' | '.join(rd) + ' |')
            if len(rows_data) > 11:
                sheet_lines.append(f'\n*... \u5171 {len(rows_data)-1} \u884c\u6570\u636e\uff0c\u5df2\u5c55\u793a\u524d {limit} \u884c ...*')
        sheets.append('\n'.join(sheet_lines))
    content = '\n\n'.join(sheets)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(content)
    return {"images_total": 0}

def convert_pdf(filepath, output_path, media_dir):
    import fitz
    doc = fitz.open(filepath)
    pages = []
    total_imgs = 0
    for pn in range(len(doc)):
        page = doc[pn]
        page_lines = [f'<!-- Page {pn+1} -->', '']
        text = page.get_text("text").strip()
        if text:
            page_lines.append(text)
        for ii, img_info in enumerate(page.get_images(full=True)):
            try:
                xref = img_info[0]
                base = doc.extract_image(xref)
                img_name = f"{Path(filepath).stem}_p{pn+1}_{ii+1}.{base['ext']}"
                with open(os.path.join(media_dir, img_name), 'wb') as f:
                    f.write(base["image"])
                page_lines.append(f'\n![\u7b2c{pn+1}\u9875\u56fe\u7247{ii+1}](media/{img_name})\n')
                total_imgs += 1
            except:
                pass
        pages.append('\n'.join(page_lines))
    content = '\n\n---\n\n'.join(pages)
    all_text = re.sub(r'<!-- .*? -->', '', ''.join(pages)).strip()
    if len(all_text) < 50 and total_imgs > 0:
        content = '> \u26a0\ufe0f **\u6ce8\u610f**\uff1a\u672c\u6587\u6863\u7591\u4f3c\u626b\u63cf\u4ef6\uff0c\u6587\u5b57\u8bc6\u522b\u53ef\u80fd\u4e0d\u5b8c\u6574\u3002\n> \u5efa\u8bae\u4f7f\u7528 OCR \u5de5\u5177\u8fdb\u4e00\u6b65\u5904\u7406\u3002\n\n' + content
    doc.close()
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(content)
    result = {"images_total": total_imgs}
    if len(all_text) < 50 and total_imgs > 0:
        result["ocr_needed"] = True
    return result

CONVERTERS = {'.docx': convert_docx, '.pptx': convert_pptx, '.xlsx': convert_xlsx, '.pdf': convert_pdf}
SUPPORTED = {'.docx', '.pptx', '.xlsx', '.pdf'}

def main():
    p = argparse.ArgumentParser(description='\u6587\u6863\u6279\u91cf\u8f6c\u6362 \u2192 Markdown')
    p.add_argument('--source', default='./input')
    p.add_argument('--output', default='./output')
    args = p.parse_args()
    
    os.makedirs(os.path.join(args.output, ".kb_cache", "convert"), exist_ok=True)
    os.makedirs(os.path.join(args.output, "media"), exist_ok=True)
    state = load_state(args.output)
    
    # 递归扫描源目录
    source_files = []
    for root, dirs, files in os.walk(args.source):
        for file in files:
            if os.path.splitext(file)[1].lower() in SUPPORTED:
                # 保持相对路径结构
                rel_path = os.path.relpath(os.path.join(root, file), args.source)
                source_files.append(rel_path)
    
    print(f"\u53d1\u73b0 {len(source_files)} \u4e2a\u6587\u4ef6\u5f85\u8f6c\u6362")
    
    # 确保状态初始化
    if "files" not in state:
        state["files"] = {}
    
    results = {}
    for idx, fname in enumerate(source_files, 1):
        filepath = os.path.join(args.source, fname)
        ext = os.path.splitext(fname)[1].lower()
        output_filename = os.path.splitext(fname)[0] + '.md'
        output_path = os.path.join(args.output, output_filename)
        
        # 确保输出目录存在
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        fhash = file_md5(filepath)
        cache_path = os.path.join(args.output, ".kb_cache", "convert", f"{fhash}.md")
        
        if os.path.exists(cache_path):
            print(f"[{idx}/{len(source_files)}] \u2705 {fname} (\u7f13\u5b58\u547d\u4e2d)")
            import shutil
            shutil.copy2(cache_path, output_path)
            results[fname] = {"images_total": 0, "cached": True}
            state["files"][fname] = {"status": "completed", "output": output_filename, "file_hash": fhash, "images_total": 0, "images_described": 0, "error": None}
        else:
            try:
                conv_result = CONVERTERS[ext](filepath, output_path, os.path.join(args.output, "media"))
                print(f"[{idx}/{len(source_files)}] \u2705 {fname} ({conv_result['images_total']} \u5f20\u56fe\u7247)")
                
                with open(output_path, 'r', encoding='utf-8') as cf:
                    cleaned = clean_markdown(cf.read())
                with open(output_path, 'w', encoding='utf-8') as cf:
                    cf.write(cleaned)
                
                with open(output_path, 'r', encoding='utf-8') as cf:
                    with open(cache_path, 'w', encoding='utf-8') as ccf:
                        ccf.write(cf.read())
                
                results[fname] = conv_result
                state["files"][fname] = {"status": "completed", "output": output_filename, "file_hash": fhash, "images_total": conv_result["images_total"], "images_described": 0, "error": None}
            except Exception as e:
                print(f"[{idx}/{len(source_files)}] \u274c {fname}: {e}")
                results[fname] = {"error": str(e), "images_total": 0}
                state["files"][fname] = {"status": "failed", "output": output_filename, "file_hash": fhash, "images_total": 0, "images_described": 0, "error": str(e)}
        save_state(state, args.output)
    
    print(f"\n\u8f6c\u6362\u5b8c\u6210: {sum(1 for v in results.values() if 'error' not in v)}/{len(source_files)} \u6210\u529f")
    return results

if __name__ == "__main__":
    main()
