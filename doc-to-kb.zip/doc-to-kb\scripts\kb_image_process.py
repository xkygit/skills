# -*- coding: utf-8 -*-
"""
图片预筛选 + pHash去重
用法: python kb_image_process.py --media ./output/media --cache ./output/.kb_cache/images
输出: .image_todo.json (待描述清单)
"""
import os, json, argparse
from datetime import datetime
from PIL import Image
import imagehash

MIN_SIZE_KB = 30
MIN_AREA = 400 * 300
HAMMING_THRESHOLD = 5

def get_image_info(img_path):
    try:
        img = Image.open(img_path)
        size_kb = os.path.getsize(img_path) / 1024
        w, h = img.size
        phash = str(imagehash.phash(img, hash_size=16))
        return {"path": img_path, "name": os.path.basename(img_path), "size_kb": round(size_kb, 1), "width": w, "height": h, "phash": phash, "area": w * h}
    except:
        return None

def hamming_distance(h1, h2):
    return bin(int(h1, 16) ^ int(h2, 16)).count('1')

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--media', default='./output/media')
    p.add_argument('--cache', default='./output/.kb_cache/images')
    args = p.parse_args()
    
    os.makedirs(args.cache, exist_ok=True)
    
    all_images = []
    for fn in sorted(os.listdir(args.media)):
        ext = os.path.splitext(fn)[1].lower()
        if ext in ('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp'):
            info = get_image_info(os.path.join(args.media, fn))
            if info:
                all_images.append(info)
    
    print(f"Total images: {len(all_images)}")
    
    to_describe = []
    skipped_decorative = []
    skipped_duplicate = []
    seen_hashes = {}
    cached = {}
    
    if os.path.exists(args.cache):
        for cf in os.listdir(args.cache):
            if cf.endswith('.json'):
                try:
                    with open(os.path.join(args.cache, cf), 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        cached[data.get('phash', cf)] = data.get('description', '')
                except:
                    pass
    
    cache_hits = 0
    
    for img in all_images:
        is_small = img['size_kb'] < MIN_SIZE_KB or img['area'] < MIN_AREA
        is_dup = False
        dup_of = None
        for seen_phash, seen_name in seen_hashes.items():
            if hamming_distance(img['phash'], seen_phash) < HAMMING_THRESHOLD:
                is_dup = True
                dup_of = seen_name
                break
        
        if is_small:
            skipped_decorative.append(img['name'])
            desc = '[装饰图]'
            rtype = 'decorative'
        elif is_dup:
            skipped_duplicate.append((img['name'], dup_of))
            desc = f'[重复图，同{dup_of}]'
            rtype = 'duplicate'
        else:
            if img['phash'] in cached:
                desc = cached[img['phash']]
                rtype = 'cached'
                cache_hits += 1
            else:
                to_describe.append(img)
                rtype = 'todo'
                desc = None
            seen_hashes[img['phash']] = img['name']
        
        status = {'decorative': 'SKIP(小/装饰)', 'duplicate': 'DUP(重复)', 'cached': 'HIT(缓存)', 'todo': 'TODO(需描述)'}[rtype]
        print(f"  {status:15s} | {img['name']:50s} | {img['size_kb']:6.1f}KB | {img['width']}x{img['height']}")
        
        if desc and rtype != 'todo':
            cache_file = os.path.join(args.cache, f"{img['phash'][:16]}.json")
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump({"phash": img['phash'], "description": desc, "desc_type": rtype, "source_file": img['name'], "cached_at": datetime.now().isoformat()}, f, ensure_ascii=False, indent=2)
    
    print(f"\n{'='*50}")
    print(f"STATS: Total={len(all_images)} | Skip(decorative)={len(skipped_decorative)} | Skip(duplicate)={len(skipped_duplicate)} | CacheHit={cache_hits} | NeedDescribe={len(to_describe)}")
    print(f"{'='*50}")
    
    todo_file = os.path.join(args.media, "..", ".image_todo.json")
    with open(todo_file, 'w', encoding='utf-8') as f:
        json.dump({"total_todo": len(to_describe), "images": [{"path": img['path'], "name": img['name'], "phash": img['phash'], "size_kb": img['size_kb'], "width": img['width'], "height": img['height']} for img in to_describe]}, f, ensure_ascii=False, indent=2)
    
    print(f"\nTodo list: {todo_file} ({len(to_describe)} images)")

if __name__ == "__main__":
    main()
