# -*- coding: utf-8 -*-
"""
收尾：注入图片描述 + YAML元数据 + 摘要 + 索引构建
用法: python kb_finalizer.py --output ./output
"""
import os, json, re, argparse
from datetime import datetime
from pathlib import Path

def load_all_descriptions(cache_dir):
    descriptions = {}
    if os.path.exists(cache_dir):
        for f in os.listdir(cache_dir):
            if f.endswith('.json'):
                try:
                    with open(os.path.join(cache_dir, f), 'r', encoding='utf-8') as fh:
                        data = json.load(fh)
                        src = data.get('source_file', '')
                        if src:
                            descriptions[src] = data.get('description', '')
                except:
                    pass
    return descriptions

def detect_doc_type(filename):
    name_lower = filename.lower()
    for ext in ['.pptx', '.docx', '.xlsx', '.pdf']:
        if ext in name_lower:
            return ext[1:]
    return 'unknown'

def generate_summary(content, doc_type, source_name):
    combined = re.sub(r'[#*`\[\]|>]', '', content[:500])
    combined = re.sub(r'\s+', ' ', combined).strip()
    type_labels = {'pptx': '培训PPT', 'docx': 'Word文档', 'xlsx': 'Excel表格', 'pdf': 'PDF文档'}
    label = type_labels.get(doc_type, '文档')
    summary = f"{label}《{source_name}》，{combined[:80]}"
    return summary[:100]

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', default='./output')
    args = p.parse_args()
    
    cache_dir = os.path.join(args.output, ".kb_cache", "images")
    descriptions = load_all_descriptions(cache_dir)
    print(f"Loaded {len(descriptions)} image descriptions from cache")
    
    md_files = [f for f in os.listdir(args.output) if f.endswith('.md') and f != 'index.md']
    stats = {"total_files": len(md_files), "files_detail": []}
    
    for md_file in sorted(md_files):
        md_path = os.path.join(args.output, md_file)
        with open(md_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        img_pattern = r'!\[([^\]]*)\]\(media/([^\)]+)\)'
        images_found = re.findall(img_pattern, content)
        described = 0
        decorative = 0
        
        def replace_image(match):
            nonlocal described, decorative
            img_name = match.group(2)
            desc = descriptions.get(img_name, '')
            if not desc or desc == '[装饰图]' or '[重复图' in desc:
                decorative += 1
                desc = desc or '[装饰图]'
            else:
                described += 1
            return match.group(0) + f"\n> \U0001f4f8 **\u56fe\u7247\u5185\u5bb9**\uff1a{desc}\n"
        
        new_content = re.sub(img_pattern, replace_image, content)
        
        doc_type = detect_doc_type(md_file)
        source_name = os.path.splitext(md_file)[0]
        summary = generate_summary(new_content, doc_type, source_name)
        
        yaml_header = f"""---
source_file: "{source_name}"
source_path: "input/{source_name}.{doc_type}"
doc_type: "{doc_type}"
images_total: {len(images_found)}
images_described: {described}
images_decorative: {decorative}
summary: "{summary}"
created_date: "{datetime.now().strftime('%Y-%m-%d')}"
kb_version: "1.0"
---

"""
        if new_content.startswith('---'):
            end_idx = new_content.find('---', 3)
            if end_idx != -1:
                new_content = new_content[end_idx+3:].lstrip('\n')
        
        new_content = yaml_header + new_content
        with open(md_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
        
        stats["files_detail"].append({"file": md_file, "type": doc_type, "images_total": len(images_found), "images_described": described, "summary": summary})
        print(f"  OK {md_file}: {len(images_found)} imgs ({described} described, {decorative} deco)")
    
    # Build index
    type_groups = {}
    for fd in stats["files_detail"]:
        t = fd["type"]
        if t not in type_groups:
            type_groups[t] = []
        type_groups[t].append(fd)
    
    type_names = {'pptx': '\U0001f4ca \u57f9\u8badPPT', 'docx': '\U0001f4dd Word\u6587\u6863', 'xlsx': '\U0001f4c8 Excel\u8868\u683c', 'pdf': '\U0001f4c4 PDF\u6587\u6863'}
    
    index = [f"# \u77e5\u8bc6\u5e93\u7d22\u5f15\n\n> \U0001f4c5 \u751f\u6210\u65f6\u95f4\uff1a{datetime.now().strftime('%Y-%m-%d %H:%M')}\n"]
    
    for dtype, files in type_groups.items():
        gn = type_names.get(dtype, dtype.upper())
        index.append(f"## {gn}\n")
        index.append("| \u6587\u4ef6 | \u7c7b\u578b | \u6458\u8981 | \u56fe\u7247\u6570 | \u5df2\u63cf\u8ff0 |")
        index.append("|------|------|------|--------|--------|")
        for fd in files:
            link_name = fd["file"].replace('.md', '')
            s = fd["summary"][:50] + "..." if len(fd["summary"]) > 50 else fd["summary"]
            index.append(f"| [{link_name}]({fd['file']}) | {dtype.upper()} | {s} | {fd['images_total']} | {fd['images_described']} |")
        index.append("")
    
    with open(os.path.join(args.output, "index.md"), 'w', encoding='utf-8') as f:
        f.write('\n'.join(index))
    
    print(f"\nIndex: {os.path.join(args.output, 'index.md')}")
    
    # Report
    total_imgs = sum(fd["images_total"] for fd in stats["files_detail"])
    total_desc = sum(fd["images_described"] for fd in stats["files_detail"])
    print(f"\nTotal: {stats['total_files']} files, {total_imgs} images, {total_desc} described")

if __name__ == "__main__":
    main()
