# -*- coding: utf-8 -*-
"""
AI批量图片描述处理 - 使用多模态模型处理图片
用法: python kb_image_describe.py --todo /path/to/.image_todo.json --output /path/to/output --batch-size 10
策略:
1. 按文档聚类（相同文档名前缀的图片）
2. 批量处理每组<=10张图片，节约token
3. 支持缓存机制，避免重复描述
4. 智能去重和内容合并
"""
import os, json, argparse
from datetime import datetime
import requests
import time
import base64
from pathlib import Path

# 配置参数
BATCH_SIZE = 10
MAX_RETRIES = 3
RETRY_DELAY = 2
GLM_API_URL = "https://open.bigmodel.cn/api/paas/v4/chat/completions"

def load_image_todo(todo_file):
    """加载待处理图片清单"""
    with open(todo_file, 'r', encoding='utf-8') as f:
        return json.load(f)

def group_by_document(images):
    """按文档名前缀分组"""
    groups = {}
    for img in images:
        # 提取文档名前缀（去掉页面号后缀）
        doc_name = img['name'].split('_')[0]
        if doc_name not in groups:
            groups[doc_name] = []
        groups[doc_name].append(img)
    return groups

def image_to_base64(image_path):
    """将图片转换为base64编码"""
    try:
        with open(image_path, 'rb') as f:
            return base64.b64encode(f.read()).decode()
    except:
        return None

def process_batch(batch_images, output_dir, cache_dir):
    """批量处理一组图片"""
    results = []
    
    # 准备图片数据
    image_data = []
    valid_images = []
    
    for img_info in batch_images:
        img_path = img_info['path']
        base64_data = image_to_base64(img_path)
        if base64_data:
            valid_images.append(img_info)
            image_data.append({
                "image_url": f"data:image/png;base64,{base64_data}",
                "filename": img_info['name'],
                "size": f"{img_info['width']}x{img_info['height']}"
            })
    
    if not valid_images:
        return results
    
    # 构建AI提示词
    prompt = f"""请为以下{len(valid_images)}张图片生成详细的文字描述，要求：

1. 逐张图片进行描述，每张图片单独说明
2. 描述要包含：主要内容和关键信息、图表类型和数据说明、界面元素和操作步骤
3. 专业术语要保持准确，特别是涉及金蝶ERP系统的业务术语
4. 对于重复内容要识别并标记
5. 每个图片描述控制在100-300字以内
6. 按以下格式输出：
   [图片1]：描述内容...
   [图片2]：描述内容...
   ...

图片信息：
{chr(10).join([f"- {img['filename']} ({img['size']})" for img in valid_images])}

请开始描述："""
    
    # 调用GLM API
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {os.getenv('GLM_API_KEY')}"
    }
    
    payload = {
        "model": "glm-4.6v",
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt}
                ] + [{"type": "image_url", "image_url": data["image_url"]} for data in image_data]
            }
        ],
        "max_tokens": 2000,
        "temperature": 0.3
    }
    
    response = None
    for attempt in range(MAX_RETRIES):
        try:
            response = requests.post(GLM_API_URL, headers=headers, json=payload, timeout=60)
            if response.status_code == 200:
                break
            time.sleep(RETRY_DELAY)
        except Exception as e:
            if attempt == MAX_RETRIES - 1:
                print(f"  ❌ 图片批次处理失败: {str(e)}")
                return results
            time.sleep(RETRY_DELAY)
    
    if response and response.status_code == 200:
        result = response.json()
        ai_response = result['choices'][0]['message']['content']
        
        # 解析AI返回的结果
        descriptions = []
        lines = ai_response.strip().split('\n')
        current_desc = ""
        
        for line in lines:
            line = line.strip()
            if line.startswith('[图片') and '：' in line:
                if current_desc:
                    descriptions.append(current_desc.strip())
                current_desc = line.split('：', 1)[1]
            elif current_desc:
                current_desc += line
        
        if current_desc:
            descriptions.append(current_desc.strip())
        
        # 验证描述数量
        if len(descriptions) != len(valid_images):
            print(f"  ⚠️ 描述数量不匹配，预期{len(valid_images)}个，得到{len(descriptions)}个")
            # 用简单描述填充缺失
            for i in range(len(descriptions), len(valid_images)):
                descriptions.append(f"{valid_images[i]['filename']}的图片描述")
        
        # 缓存结果
        for i, img_info in enumerate(valid_images):
            desc = descriptions[i] if i < len(descriptions) else f"{img_info['name']}的图片描述"
            
            cache_file = os.path.join(cache_dir, f"{img_info['phash'][:16]}.json")
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump({
                    "phash": img_info['phash'],
                    "description": desc,
                    "doc_name": img_info['name'].split('_')[0],
                    "batch_time": datetime.now().isoformat(),
                    "processed_by": "GLM-4.6v"
                }, f, ensure_ascii=False, indent=2)
            
            results.append({
                "path": img_info['path'],
                "name": img_info['name'],
                "phash": img_info['phash'],
                "description": desc
            })
            
            print(f"  ✅ {img_info['name']} - {len(desc)}字")
    
    return results

def main():
    p = argparse.ArgumentParser(description='AI批量图片描述处理')
    p.add_argument('--todo', required=True, help='待处理图片清单文件')
    p.add_argument('--output', required=True, help='输出目录')
    p.add_argument('--batch-size', type=int, default=BATCH_SIZE, help='批量处理大小')
    p.add_argument('--cache-dir', default='./.kb_cache/descriptions', help='描述缓存目录')
    
    args = p.parse_args()
    
    # 加载待处理图片
    todo_data = load_image_todo(args.todo)
    images = todo_data['images']
    
    # 创建输出目录
    os.makedirs(args.cache_dir, exist_ok=True)
    os.makedirs(os.path.join(args.output, 'media'), exist_ok=True)
    
    print(f"📸 开始处理 {len(images)} 张图片")
    
    # 按文档分组
    doc_groups = group_by_document(images)
    print(f"📁 按文档分组：{len(doc_groups)} 个文档")
    
    # 统计信息
    processed_count = 0
    total_batches = 0
    
    # 处理每个文档
    for doc_name, doc_images in doc_groups.items():
        print(f"\n📄 处理文档：{doc_name} ({len(doc_images)} 张)")
        
        # 按批次处理
        for i in range(0, len(doc_images), args.batch_size):
            batch = doc_images[i:i + args.batch_size]
            batch_num = i // args.batch_size + 1
            
            print(f"  批次 {batch_num}/{(len(doc_images) + args.batch_size - 1) // args.batch_size}")
            
            results = process_batch(batch, args.output, args.cache_dir)
            processed_count += len(results)
            total_batches += 1
            
            # 添加延迟避免API限制
            time.sleep(1)
    
    print(f"\n{'='*50}")
    print(f"📊 处理完成统计：")
    print(f"   处理图片数：{processed_count}/{len(images)}")
    print(f"   处理批次数：{total_batches}")
    print(f"   缓存目录：{args.cache_dir}")
    print(f"{'='*50}")
    
    # 生成处理报告
    report_file = os.path.join(args.output, f"image_description_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
    report_data = {
        "total_images": len(images),
        "processed_count": processed_count,
        "total_batches": total_batches,
        "completion_rate": processed_count / len(images) if len(images) > 0 else 0,
        "processing_time": datetime.now().isoformat(),
        "cache_directory": args.cache_dir
    }
    
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(report_data, f, ensure_ascii=False, indent=2)
    
    print(f"📄 处理报告：{report_file}")

if __name__ == "__main__":
    main()