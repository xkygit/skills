# 文档生成示例

## 使用前（传统方式）

```
用户："请帮我写一个API文档，包含用户管理模块的GET和POST接口。"

AI："很高兴帮您编写API文档！以下是为用户管理模块编写的详细文档：

## 用户管理API文档

### GET /api/users
获取用户列表

**请求参数：**
- page: 页码（可选，默认1）
- limit: 每页数量（可选，默认10）
- search: 搜索关键词（可选）

**响应格式：**
```json
{
  "success": true,
  "data": {
    "users": [],
    "total": 0,
    "page": 1,
    "limit": 10
  }
}
```

**示例：**
```bash
curl -X GET "http://api.example.com/api/users?page=1&limit=20"
```

### POST /api/users
创建新用户

**请求体：**
```json
{
  "username": "string",
  "email": "string",
  "password": "string"
}
```

**响应格式：**
```json
{
  "success": true,
  "data": {
    "userId": "string",
    "message": "User created successfully"
  }
}
```

希望这个文档对您有帮助！"
```

## 使用后（Caveman方式）

```
用户："请帮我写一个API文档，包含用户管理模块的GET和POST接口。"

AI："## 用户管理API

### GET /api/users
**功能**：获取用户列表
**参数**：page(1), limit(10), search
**响应**：success, data(users,total,page,limit)

### POST /api/users  
**功能**：创建用户
**请求体**：username, email, password
**响应**：success, data(userId,message)"
```