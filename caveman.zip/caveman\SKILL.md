---
name: caveman
summary: 让AI像原始人一样说话，减少75%的token消耗
author: JuliusBrussee
version: 1.0.0
description: |
  Caveman是一个Claude Code技能，通过让AI采用"原始人"语言风格来大幅减少token消耗。
  
  核心特点：
  - 减少75%的token使用
  - 去除客套话和冗余信息
  - 提高信息密度和准确性
  - 保持技术正确性

usage: |
  在需要减少token消耗的场景中使用caveman技能。
  
  工作原理：
  1. 采用简洁、直接的表达方式
  2. 去除不必要的礼貌用语
  3. 压缩重复信息
  4. 保持核心技术内容的准确性

installation: |
  1. 将此技能放入~/.workbuddy/skills/目录
  2. 重启Claude Code
  3. 在对话中调用caveman技能

trigger_keywords: |
  caveman
  简洁
  压缩
  少废话
  节省token
  减少token

examples: |
  # 使用前
  "您好！我很乐意帮助您解决这个问题。根据我的分析，我建议您采取以下步骤..."
  
  # 使用后
  "问题：分析错误。建议：检查配置，重启服务。确认结果。"

files:
  - "SKILL.md"
  - "README.md"
  - "examples/"

dependencies: []
license: MIT
---