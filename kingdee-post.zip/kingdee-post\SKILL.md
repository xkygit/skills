---
name: kingdee-post
description: 将金蝶云星空操作步骤数据转化为可视化SVG流程图。当用户提供金蝶操作步骤表格（含步骤序号、步骤名称、操作说明、注意事项）并要求生成流程图、可视化、或图示时使用此技能。适用于金蝶ERP相关操作流程文档化场景，包括但不限于车间作业成本、工序在制盘点、成本计算、库存台账配置、权限配置等操作流程。触发关键词：流程图、可视化、图示、操作步骤、操作流程、金蝶流程、画图。
---

# kingdee-post — 金蝶操作步骤流程图生成器

将用户提供的金蝶云星空操作步骤数据，自动生成紧凑、美观、分色编码的SVG流程图。

## 输入格式

用户通常提供以下结构的步骤数据（表格或文本均可）：

| 步骤序号 | 步骤名称 | 操作说明 | 注意事项 |
|---------|---------|---------|---------|
| 1 | xxx | ... | ... |

每行代表一个流程节点，包含4个字段：序号、名称、操作说明（必填）、注意事项（可选）。

## 输出规范

使用 `show_widget` 工具生成内联SVG流程图，严格遵循以下规范：

### 1. 整体布局

- SVG viewBox 固定宽度 **680**，高度按内容计算
- 节点宽度 **450px**（3/4画布宽），水平居中（x=115）
- 节点之间箭头间距 **14px**
- 背景 `#F8F7F4`，圆角12px

### 2. 节点结构

每个节点由三部分组成，**零底部空白**：

```
┌──────────────────────┐ ← 标题栏（28px高，深色填充，白色文字）
│  步骤N  步骤名称     │
├──────────────────────┤ ← 内容区（高度=文字行数×行高，无多余padding）
│  操作：xxx           │
│  注意：yyy           │
└──────────────────────┘ ← 文字末行紧贴框线
```

- 标题栏：28px高，步骤名称白色，字号12px，font-weight 500
- 内容区：使用 `foreignObject` 渲染HTML，字号11px，行高1.5
- 内容区高度计算：行数 × 16.5px（11px × 1.5），仅保留约2px底部边距
- 节点总高度 = 28（标题）+ 内容区高度 + 2（微量底部）
- 圆角 8px

### 3. 颜色编码

根据步骤类型分配颜色，通过步骤名称和内容语义判断：

| 类型 | 颜色方案 | 适用步骤 | 填充色 | 描边色 | 标题栏色 |
|------|---------|---------|--------|--------|---------|
| 前置配置 | 蓝色 | 初始化、启用、设置等前置一次性操作 | #E6F1FB | #185FA5 | #185FA5 |
| 常规操作 | 绿色 | 创建、录入、审核、获取等日常操作 | #E1F5EE | #0F6E56 | #0F6E56 |
| 关键标记 | 橙色 | 全局盘点、特殊标记等关键转折点 | #FAEEDA | #854F0B | #854F0B |
| 结果输出 | 深绿 | 计算、查看结果等产出步骤 | #EAF3DE | #3B6D11 | #3B6D11 |
| 可选步骤 | 灰色虚线 | 可选的自动化或扩展操作 | #F1EFE8 | #5F5E5A | #5F5E5A |

注意事项文字统一使用 **#993C1D**（橙红色），以 `<b style="color:#993C1D;">注意：</b>` 开头。

可选步骤的节点描边使用虚线 `stroke-dasharray="6,3"`，连接箭头也用虚线 `stroke-dasharray="6,4"`。

### 4. 连接箭头

- 使用 `marker-end="url(#arrow)"` 定义箭头
- 箭头颜色 `#534AB7`
- 线宽 1.5px
- 可选步骤的箭头使用虚线

### 5. 图例

流程图底部放置图例，说明各颜色含义：

```svg
<g transform="translate(115, Y)">
  <!-- 每种类型一个小色块+文字 -->
</g>
```

图例项：前置配置（蓝）、常规操作（绿）、关键标记（橙）、结果输出（深绿）、可选步骤（灰虚线）、● 注意事项（橙红）

### 6. SVG 模板

以下是节点的标准SVG结构，直接复用：

```svg
<defs>
  <marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5"
    markerWidth="6" markerHeight="6" orient="auto-start-reverse">
    <path d="M2 1L8 5L2 9" fill="none" stroke="#534AB7"
      stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  </marker>
</defs>

<!-- 单个节点 -->
<g>
  <!-- 外框 -->
  <rect x="115" y="Y" width="450" height="H" rx="8" fill="FILL" stroke="STROKE" stroke-width="0.8"/>
  <!-- 标题栏背景 -->
  <rect x="115" y="Y" width="450" height="28" rx="8" fill="STROKE"/>
  <rect x="115" y="Y+20" width="450" height="8" fill="STROKE"/>
  <!-- 标题文字 -->
  <text x="130" y="Y+14" dominant-baseline="central"
    font-family="system-ui,-apple-system,sans-serif"
    font-size="12" font-weight="500" fill="white">步骤N  名称</text>
  <!-- 内容 -->
  <foreignObject x="122" y="Y+30" width="436" height="CONTENT_H">
    <div xmlns="http://www.w3.org/1999/xhtml"
      style="font-family:system-ui,-apple-system,sans-serif;font-size:11px;line-height:1.5;color:TEXT_COLOR;">
      <b>操作：</b>操作说明内容
      <b style="color:#993C1D;">注意：</b><span style="color:#993C1D;">注意事项内容</span>
    </div>
  </foreignObject>
</g>

<!-- 箭头 -->
<line x1="340" y1="Y+H" x2="340" y2="NEXT_Y"
  stroke="#534AB7" stroke-width="1.5" marker-end="url(#arrow)"/>
```

## 工作流程

1. **解析输入**：从用户提供的表格/文本中提取每个步骤的序号、名称、操作说明、注意事项
2. **分类着色**：根据步骤语义判断类型，分配颜色方案
3. **计算布局**：逐个节点计算内容高度和Y坐标，确保无底部空白
4. **生成SVG**：按模板组装完整SVG代码
5. **渲染展示**：使用 `show_widget` 工具渲染流程图

## 注意事项

- 所有文字内容必须完整显示，不得截断或省略
- 注意事项中的序号（①②③...）保留原样
- 公式保留原格式（如计算公式中的乘号、除号）
- 如果步骤超过10个，考虑将流程图拆分为多个 `show_widget` 调用
- foreignObject 中的 HTML 内容不要包含 DOCTYPE、html、head、body 标签
- 内容区的高度要精确匹配文字行数，最后一行文字与框线之间不留空白
