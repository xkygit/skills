#!/usr/bin/env python3
"""金蝶知识库文章抓取工具
用法: python kingdee-fetch.py <知识文章ID>
"""
import sys, json, re, urllib.request

def html_to_md(html):
    """将金蝶文章的 HTML 正文转换为 Markdown"""
    if not html:
        return html
    # 先处理换行
    text = html.replace('\\n', '\n')
    # 零宽空格等不可见字符剔除
    text = re.sub(r'[​‌‍‎‏﻿]', '', text)
    # 代码块（必须在其他标签之前处理，因为 pre 内可能有 HTML 实体）
    text = re.sub(r'<pre[^>]*>(.*?)</pre>', r'\n```\n\1\n```\n', text, flags=re.DOTALL)
    # 解码 HTML 实体（&nbsp; &lt; &gt; &amp; &#39; &quot;）
    text = text.replace('&nbsp;', ' ').replace('&lt;', '<').replace('&gt;', '>')
    text = text.replace('&amp;', '&').replace('&#39;', "'").replace('&quot;', '"')
    # 图片
    text = re.sub(r'<img[^>]+src=["\']([^"\']+)["\'][^>]*/?>', r'![](\1)', text)
    # 链接
    text = re.sub(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', r'[\2](\1)', text)
    # 标题
    text = re.sub(r'<h3[^>]*>(.*?)</h3>', r'\n### \1\n', text)
    text = re.sub(r'<h2[^>]*>(.*?)</h2>', r'\n## \1\n', text)
    text = re.sub(r'<h4[^>]*>(.*?)</h4>', r'\n#### \1\n', text)
    # 加粗
    text = re.sub(r'<strong[^>]*>(.*?)</strong>', r'**\1**', text)
    # 段落 → 换行
    text = re.sub(r'<p[^>]*>', '', text)
    text = re.sub(r'</p>', '\n\n', text)
    # 换行标签
    text = re.sub(r'<br\s*/?>', '\n', text)
    # span / font 等样式标签：只保留内容
    text = re.sub(r'</?span[^>]*>', '', text)
    text = re.sub(r'</?font[^>]*>', '', text)
    # 剔除剩余所有 HTML 标签
    text = re.sub(r'<[^>]+>', '', text)
    # 压缩多余空行
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()

def main():
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
    if len(sys.argv) < 2:
        print("用法: python kingdee-fetch.py <知识文章ID或URL> [输出文件]", file=sys.stderr)
        sys.exit(1)

    raw = sys.argv[1]
    m = re.search(r'(\d{10,})', raw)
    if not m:
        print("错误: 请提供有效的知识文章ID", file=sys.stderr)
        sys.exit(1)
    kid = m.group(1)

    url = f"https://vip.kingdee.com/knowledgeapi/knowledge/{kid}"
    req = urllib.request.Request(url, headers={
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Referer": f"https://vip.kingdee.com/knowledge/{kid}",
    })
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())
    except Exception as e:
        print(f"错误: 获取文章失败 - {e}", file=sys.stderr)
        sys.exit(1)

    title = data.get('title') or data.get('editTitle', '')
    desc = data.get('description', '')
    content = html_to_md(data.get('content') or data.get('editContent', ''))

    # 补全相对路径图片 URL → 绝对路径
    def abs_img_url(m):
        prefix = m.group(1)  # ![alt text]
        url = m.group(2)
        if url.startswith('/'):
            return f'{prefix}(https://vip.kingdee.com{url})'
        return m.group(0)
    content = re.sub(r'(!\[.*?\])\(([^)]+)\)', abs_img_url, content)

    creator = data.get('knowledgeCreator', {}).get('name', '未知')
    views = data.get('views', 0)
    collections = data.get('collections', 0)
    useful = data.get('useful', 0)
    unuseful = data.get('unuseful', 0)
    labels = [l.get('name', '') for l in data.get('labels', [])]
    classifies = data.get('classifies', [])

    def classify_path(c):
        parts = []
        while c:
            parts.append(c.get('name', ''))
            c = c.get('child')
        return ' > '.join(parts)

    paths = [classify_path(c) for c in classifies]

    lines = []
    lines.append('---')
    lines.append(f'title: {title}')
    lines.append(f'description: {desc}')
    lines.append(f'author: {creator}')
    if labels:
        lines.append(f'tags: {", ".join(labels)}')
    if paths:
        lines.append(f'categories: {", ".join(paths)}')
    lines.append(f'views: {views}')
    lines.append(f'collections: {collections}')
    lines.append(f'useful: {useful}')
    lines.append(f'id: {kid}')
    lines.append('---')
    lines.append('')
    if desc:
        lines.append(f'> {desc}')
        lines.append('')
    lines.append(f'**作者**: {creator} | **浏览**: {views} | **收藏**: {collections} | **有用**: {useful}')
    if labels:
        lines.append('')
        lines.append(f'**标签**: {", ".join(labels)}')
    if paths:
        lines.append('')
        lines.append(f'**分类路径**: {", ".join(paths)}')
    lines.append('')
    if content:
        lines.append(content)

    attachments = data.get('attachments', [])
    if attachments:
        lines.append('')
        lines.append('## 附件')
        for att in attachments:
            lines.append(f'- [{att.get("name", "")}]({att.get("url", "")})')

    if content:
        md_imgs = re.findall(r'!\[.*?\]\((.*?)\)', content)
        html_imgs = re.findall(r'<img[^>]+src=["\']([^"\']+)["\']', content)
        all_imgs = list(set(md_imgs + html_imgs))
        if all_imgs:
            lines.append('')
            lines.append('## 图片')
            for img in all_imgs:
                img_url = f'https://vip.kingdee.com{img}' if img.startswith('/') else img
                lines.append(f'- ![]({img_url})')

    output = '\n'.join(lines)

    if len(sys.argv) >= 3:
        with open(sys.argv[2], 'w', encoding='utf-8') as f:
            f.write(output)
        print(f'已保存到: {sys.argv[2]}', file=sys.stderr)
    else:
        sys.stdout.write(output)

if __name__ == '__main__':
    main()
