---
name: kingdee-fetch
description: 抓取金蝶云社区（vip.kingdee.com）知识库文章并转为 Markdown。支持两种场景：(1) 知识库文章（/knowledge/ 或 /article/ 或 /link/）；(2) 金蝶云学院课程（/school/）。当用户提供金蝶云社区链接、文章ID，或需要读取金蝶知识库内容时使用此技能。
---

# 金蝶云社区文章抓取技能

从金蝶云社区（vip.kingdee.com）知识库抓取文章，将 HTML 内容转为干净的 Markdown 格式，包含完整的元数据（标题、作者、标签、分类路径、浏览/收藏数等）。

## 触发条件

当出现以下情况时，主动调用本技能：

**场景一：金蝶云社区知识库文章**

1. **用户提供金蝶云社区链接** — 如 `https://vip.kingdee.com/knowledge/1234567890` 或 `https://vip.kingdee.com/link/xxx`
2. **用户提供知识文章ID** — 一串 10 位以上的数字
3. **用户需要读取金蝶知识库文章内容** — 如"帮我看看这篇金蝶文章"、"抓取这个金蝶文档"
4. **在处理金蝶相关问题时需要查阅社区文章** — 与金蝶套打、BOS、权限等技能联动时，如需获取社区原文

**场景二：金蝶云学院课程**

1. **用户提供金蝶云学院链接** — 如 `https://vip.kingdee.com/school/detail/xxx` 或 `https://vip.kingdee.com/link/xxx`（重定向到 /school/）
2. **用户需要提取金蝶云学院课程内容** — 如"提取这个课程"、"获取学院专题内容"
3. **用户需要从金蝶学习平台导出课程资料** — 批量获取学习内容

## 工作流程

### 步骤 1：提取文章 ID

从用户输入中提取文章 ID。支持以下格式：

- 完整 URL：`https://vip.kingdee.com/knowledge/1234567890` → 提取 `1234567890`
- 短链接：`https://vip.kingdee.com/link/xxx` → 需先通过 WebFetch 跟随重定向获取实际 knowledge ID
- 纯数字 ID：`1234567890` → 直接使用

### 步骤 2：运行抓取脚本

使用 Bash 工具执行脚本：

```bash
C:\Users\Administrator\.workbuddy\binaries\python\versions\3.14.3\python.exe "{{SKILL_PATH}}/scripts/kingdee-fetch.py" <文章ID>
```

如果需要保存到文件：

```bash
C:\Users\Administrator\.workbuddy\binaries\python\versions\3.14.3\python.exe "{{SKILL_PATH}}/scripts/kingdee-fetch.py" <文章ID> <输出文件路径>
```

> **注意**：脚本仅依赖 Python 标准库（`urllib`, `json`, `re`），无需安装任何第三方包。

### 步骤 3：处理输出

脚本输出结构化 Markdown，格式如下：

```markdown
---
title: 文章标题
description: 文章摘要
author: 作者
tags: 标签1, 标签2
categories: 分类路径1, 分类路径2
views: 浏览数
collections: 收藏数
useful: 有用数
id: 文章ID
---

> 文章摘要

**作者**: xxx | **浏览**: xxx | **收藏**: xxx | **有用**: xxx
**标签**: xxx
**分类路径**: xxx

正文内容（已转为 Markdown）...

## 附件
- [附件名](附件URL)

## 图片
- ![](图片URL)
```

### 步骤 4：根据用户需求使用内容

- 如果用户只是要读取文章：直接展示转换后的 Markdown 内容
- 如果用户需要基于文章内容进行分析：读取后结合其他技能（如金蝶套打、BOS 参考等）进行回答
- 如果用户要保存文章：将输出写入指定的文件路径

---

## 金蝶云学院课程提取流程

当用户提供金蝶云学院链接（如 `https://vip.kingdee.com/school/detail/xxx` 或 `https://vip.kingdee.com/link/xxx`）时，使用以下流程：

### 前置条件

- 浏览器中已登录金蝶云社区账号（否则只能看到试看提示，无法提取正文）
- 用户已兑换/拥有该专题的访问权限

### 步骤 1：连接浏览器并打开页面

使用 Playwright MCP 工具导航到课程 URL：

```
mcp__playwright__browser_navigate(url: "https://vip.kingdee.com/school/detail/xxx")
```

### 步骤 2：提取专题概览

使用 `mcp__playwright__browser_evaluate` 提取页面信息：

```javascript
() => {
  return document.title + '\n\n' + document.body.innerText.substring(0, 5000);
}
```

获取内容包含：
- 专题标题、简介
- 预计学习时长
- 课程目录列表（标题、时长、学习状态）

### 步骤 3：获取所有课程/问题 URL

**不要逐个点击课程链接**——这容易遇到元素引用失效、页面跳转异常等问题。

改用 JavaScript 一次性获取所有链接：

```javascript
() => {
  const links = Array.from(document.querySelectorAll('a'))
    .map(a => ({text: a.innerText.trim(), href: a.href}))
    .filter(x => x.text.includes('点击查看') || x.href.includes('/article/') || x.href.includes('/knowledge/'));
  return JSON.stringify(links);
}
```

将获取到的 URL 列表保存，用于步骤 4 并行提取。

### 步骤 4：并行提取详细内容

将课程/问题 URL 分组，使用多个 Agent 子代理并行提取：

- **每个子代理处理 3~5 个课程**，避免单代理超时
- 子代理流程：创建新 tab → navigate 到课程 URL → 提取内容 → 关闭 tab
- 收集每个子代理返回的课程标题和正文内容

**注意事项**：
- 若页面内容超过 50000 字符，`browser_evaluate` 可能报错，此时需适当降低提取字符数或分段提取
- 部分课程可能包含视频，正文内容在页面下方的"课程介绍"或"学习目标"区域

### 步骤 5：汇总整理

1. 将所有提取的内容按课程顺序合并
2. 每节课包含：标题、学习目标、正文内容（字段说明/SQL/表结构等）
3. 生成 Markdown 文件，包含目录导航
4. 保存到输出目录：`outputs/专题名称_课程汇总.md`

### 输出格式模板

```markdown
# [专题名称] — 课程汇总

> 来源：[URL]
> 预计学习时长：xxx

## 目录

1. [课程1标题](#1-课程1标题)
2. [课程2标题](#2-课程2标题)
...

---

## 1. 课程1标题

**发布日期：** xxx | **浏览数：** xxx | **评分：** xxx | **讲师：** xxx

### 学习目标
...

### 正文内容
...

---

## 2. 课程2标题
...
```

### 步骤 6：根据用户需求使用内容

- 如果用户只是要查看目录：直接展示提取的目录和链接
- 如果用户需要详细内容：展示提取的正文内容
- 如果用户要保存内容：将输出写入指定的 Markdown 文件

## 注意事项

1. **网络要求**：脚本需要访问 `vip.kingdee.com`，确保网络可达
2. **无需登录**：金蝶知识库的公开文章无需登录即可抓取；部分内部文章可能需要登录态，此时脚本会返回错误
3. **图片 URL**：脚本已自动将相对路径图片转为绝对路径（补全 `https://vip.kingdee.com` 前缀）
4. **HTML 转 Markdown**：脚本处理了常见的 HTML 标签（标题、加粗、链接、图片、代码块、段落等），但复杂的嵌套 HTML 可能会有少量残留标签
5. **零宽字符**：脚本已自动清除零宽空格等不可见字符

## 与其他金蝶技能的联动

| 技能 | 联动场景 |
|------|---------|
| kingdee-bos-reference | 用户提到 BOS 设计器相关的社区文章时，先抓取文章再结合 BOS 知识库回答 |
| 金蝶套打问答 | 用户提到套打相关的社区讨论时，先抓取文章再结合套打知识库回答 |
| kingdee-permission-management | 用户提到权限相关的社区文章时，先抓取文章再结合权限管理知识回答 |
| ticket-analysis | 分析工单时需要引用金蝶社区解决方案，先抓取对应文章 |

## 故障排查

| 错误 | 原因 | 解决方案 |
|------|------|---------|
| `错误: 获取文章失败` | 网络不通或文章不存在 | 检查网络，确认文章 ID 正确 |
| `错误: 请提供有效的知识文章ID` | 输入未包含 10 位以上数字 | 确认输入的是文章 ID 或包含 ID 的 URL |
| 输出内容为空 | 文章可能需要登录 | 提示用户该文章可能需要登录后才能查看 |
