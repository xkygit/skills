---
title: OnChangeConvertRuleEnumList事件
description: 
author: eris
tags: 二次开发方案, 快速入门
views: 1372
collections: 7
useful: 4
id: 188684324994891264
---

**作者**: eris | **浏览**: 1372 | **收藏**: 7 | **有用**: 4

**标签**: 二次开发方案, 快速入门

此事件为表单插件事件，注册在需要下推或选单的当前单据里，用来控制选单页面转换规则的显示。

示例：单据A到单据B有两个转换规则，现在要控制单据B在选单的时候不同的单据类型使用不同的转换规则，具体处理如下：

编写表单插件，重写BeforeDoOperation和OnChangeConvertRuleEnumList事件，代码如下：

```
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

using Kingdee.BOS.Util;
using Kingdee.BOS.Core;
using Kingdee.BOS.Core.DynamicForm.PlugIn.Args;
using Kingdee.BOS.Core.Bill.PlugIn;
using Kingdee.BOS.Core.Metadata.FieldElement;
using Kingdee.BOS.Orm.DataEntity;

namespace Kingdee.BOS.TestPlugIn22.FormPlugin
{
    [HotUpdate]
    [Description("单据测试插件")]
```

```
      public class TestFormPlugIn : AbstractBillPlugIn
    {

        private bool _isDraw = false; //是否为选单操作

        /// 
        /// 选单时根据不同的单据类型显示转换规则
        /// 
        /// 
        public override void OnChangeConvertRuleEnumList(Core.List.PlugIn.Args.ChangeConvertRuleEnumListEventArgs e)
        {
            base.OnChangeConvertRuleEnumList(e);
            if (this._isDraw)
            {
                var statusField = this.View.BillBusinessInfo.GetBillTypeField();
                var statusObj = this.Model.GetValue(statusField) as DynamicObject;
                if (statusObj != null)
                {
                    if (statusObj["Name"].ToString().Equals("单据类型1")) //EnumId为转换规则唯一标识
                    {
                        e.ConvertRuleEnumList.RemoveAll(x => x.EnumId != "c9b41092-f23d-4888-891d-de1faeb7b1a8");
                    }
                    else if (statusObj["Name"].ToString().Equals("单据B类型2"))
                    {
                        e.ConvertRuleEnumList.RemoveAll(x => x.EnumId != "1299669a-733b-475f-b651-a0e2aa916500");
                    }
                }
            }
        }

        /// 
        /// 操作前事件,确定什么操作
        /// 
        /// 
        public override void BeforeDoOperation(BeforeDoOperationEventArgs e)
        {
            base.BeforeDoOperation(e);
            this._isDraw = false;
            if (e.Operation.FormOperation.Operation == "Draw")
            {
                this._isDraw = true;
            }
        }
    }
```
2. 单据B上注册表单插件

![插件配置截图](images/img_31a000c6fda74ac4a7bbd642b93c41e0.png)

> **📸 图解操作流程**
>
> 1. [步骤1] 操作动作：查看/打开，界面元素：单据B - 属性面板（表单插件配置），当前界面：BOS IDE-属性配置窗口，备注：打开单据B的设计视图，在右侧属性面板中找到"表单插件"属性行（红框标注区域）
> 2. [步骤2] 操作动作：点击/注册，界面元素：表单插件值区域 - 插件选择对话框，当前界面：插件配置信息弹窗，备注：点击"表单插件"属性的值区域或展开按钮，打开插件选择对话框，在其中注册上面编写的TestFormPlugIn插件类（Kingdee.BOS.TestPlugIn22.FormPlugin.TestFormPlugIn）

3. 运行效果，单据类型1显示转换规则类型1，单据B类型2显示转换规则类型2.

![插件代码或注册界面截图](https://vip.king![金蝶云星空截图](images/img_b6d74d1b21fa4e3faba130c07153df59.png)//vip.kingdee.com/download/01![金蝶云星空截图](images/img_b6d74d1b21fa4e3faba130c07153df59.png)/010031a000c6fda74ac4a![金蝶云星空截图](images/img_31a000c6fda74ac4a7bbd642b93c41e0.png)

> **📸 图解操作流程**
>
> 1. [步骤1] 操作动作：触发，界面元素：选单按钮/菜单，当前界面：单据B-新增窗口，备注：在单据B的新增界面执行选单操作（从源单据A选择数据）
> 2. [步骤2] 操作动作：选择，界面元素：单据类型字段 - 下拉框，当前界面：单据B-新增窗口，备注：在单据头"单据类型"下拉框中选择"单据类型1"
> 3. [步骤3] 操作动作：查看，界面元素：转换规则下拉列表，当前界面：选单页面-参数选择区域，备注：确认转换规则下拉列表中仅显示了与"单据类型1"对应的转换规则（如规则ID为"c9b41092-f23d-4888-891d-de1faeb7b1a8"的规则），其他规则已被过滤隐藏（红框标注区域显示过滤后的结果）
> 4. [步骤4] 操作动作：切换，界面元素：单据类型字段 - 下拉框，当前界面：单据B-新增窗口，备注：将单据类型切换为"单据B类型2"
> 5. [步骤5] 操作动作：查看，界面元素：转换规则下拉列表（更新后），当前界面：选单页面-参数选择区域，备注：确认转换规则下拉列表现在仅显示与"单据B类型2"对应的转换规则（如规则ID为"1299669a-733b-475f-b651-a0e2aa916500"的规则），验证OnChangeConvertRuleEnumList事件成功实现了根据单据类型动态控制转换规则显示的功能
