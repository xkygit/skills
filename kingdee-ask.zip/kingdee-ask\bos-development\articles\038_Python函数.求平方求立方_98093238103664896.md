---
title: 二开案例.Python函数.求平方求立方
author: Jack
category: 值更新与实体服务
tags: 二次开发方案, 快速入门
views: 6026
collections: 10
useful: 11
source: https://vip.kingdee.com/knowledge/98093238103664896
entityId: 98093238103664896
---

【应用场景】Python表达式中进行平方或者立方计算。

【案例演示】采购订单，新增两个整数字段，进行求平方、求立方计算。

【实现步骤】

登录BOSIDE，扩展采购订单，新增两个整数字段，其中的【整数】字段设置值更新事件，如下图所示。

<!-- 原图: https://vip.kingdee.com/download/010058cb900f33a94d2b917f10731142d8ce.png -->
![](./images/038_Python函数_求平方求立方_9809323810_图1_010058cb900f33a94d2b.png)

表达式：**F_Jac_Integer = int(F_Jac_Integer1) ** 2**

新增两个小数字段，其中的【小数】字段设置值更新事件，如下图所示。

<!-- 原图: https://vip.kingdee.com/download/01005c5c42a09b664ab3ae81c57b00c2d9ec.png -->
![](./images/038_Python函数_求平方求立方_9809323810_图2_01005c5c42a09b664ab3.png)

表达式：**F_Jac_Decimal = float(F_Jac_Decimal1) ** 3**

保存元数据，开发完毕。

现在可以登录业务站点，打开采购订单，检查一下配置的表达式的运行效果啦。

<!-- 原图: https://vip.kingdee.com/download/010057a204a49d9a4fd4a1396f29f8a3ca2e.png -->
![](./images/038_Python函数_求平方求立方_9809323810_图3_010057a204a49d9a4fd4.png)

【星空BOS二次开发案例演示】[https://vip.kingdee.com/article/94751030918525696](https://vip.kingdee.com/article/94751030918525696)