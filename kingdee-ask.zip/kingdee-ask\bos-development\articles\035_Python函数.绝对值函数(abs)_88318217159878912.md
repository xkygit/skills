---
title: 二开案例.Python函数.绝对值函数(abs)
author: Jack
category: 值更新与实体服务
tags: 二次开发方案, 快速入门
views: 7162
collections: 30
useful: 16
source: https://vip.kingdee.com/knowledge/88318217159878912
entityId: 88318217159878912
---

【应用场景】计算数字的绝对值。

【案例演示】采购订单，新增小数字段1和小数字段2，设置小数字段2等于小数字段1的绝对值。

【实现步骤】

BOSIDE，扩展采购订单，新增小数字段1和小数字段2。

<!-- 原图: https://vip.kingdee.com/download/010084ba93b03ef14590919a3931f79e7867.png -->
![](./images/035_Python函数_绝对值函数_abs__883182_图1_010084ba93b03ef14590.png)

小数字段1设置值更新事件，公式如下。

F_PAEZ_Decimal1 = **abs**(**float**(F_PAEZ_Decimal))

【注】因为abs函数只支持int和float，因此需要先进行类型转换，再取绝对值。

<!-- 原图: https://vip.kingdee.com/download/01008cb538adb6024d0d9bc7abc63f95df14.png -->
![](./images/035_Python函数_绝对值函数_abs__883182_图2_01008cb538adb6024d0d.png)

保存元数据，开发完毕。

现在去登录业务站点，打开采购订单，测试一下表达式效果把：）

<!-- 原图: https://vip.kingdee.com/download/01001e623c6842fb41ce955099c383f1ea45.png -->
![](./images/035_Python函数_绝对值函数_abs__883182_图3_01001e623c6842fb41ce.png)

【星空BOS二次开发案例演示】[https://vip.kingdee.com/article/94751030918525696](https://vip.kingdee.com/article/94751030918525696)