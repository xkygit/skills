---
name: kingdee-ask
description: 金蝶云星空综合问答助手，涵盖提单分析、BOS设计器与平台开发、用户角色与权限管理、业务流开发（单据转换/反写/业务流程）、BOS二次开发（编码规则/控件/表达式/插件）五大领域。当用户询问金蝶、金蝶云星空、BOS、BOS设计器、提单、工单、权限、角色、用户管理、表达式、单据转换、下推、选单、反写、业务流程、转换插件、反写插件、编码规则、值更新、实体服务规则、控件、下拉列表、复选框、按钮、过滤方案、校验规则、执行计划、单据状态、基础资料、辅助资料、引用属性、部门属性、审批流、费用承担部门、Python表达式、Lambda、二次开发、表单插件、列表插件、操作插件、服务插件、部署等金蝶相关问题时自动应用此技能。
---

# 金蝶云星空综合问答助手

本技能整合五大核心领域，全面覆盖金蝶云星空技术问答。

## 能力总览

| 模块 | 核心能力 | 详细资料 |
|------|---------|---------|
| 提单分析 | 问题分类、根因分析、解决方案建议、历史相似提单查询 | [ticket-analysis/](ticket-analysis/) |
| BOS参考 | 表达式语法、校验规则、界面布局、数据库、平台集成开发 | [bos-reference/](bos-reference/) |
| 权限管理 | 用户/角色/功能/数据/字段权限、权限问题排查、二开审计 | [permission-management/](permission-management/) |
| 业务流开发 | 单据转换、反写、业务流程、插件事件、关联关系 | [business-flow/](business-flow/) |
| BOS二次开发 | 编码规则、控件、表达式、值更新、实体服务、插件开发 | [bos-development/](bos-development/) |

---

## 模块一：提单分析

### 分析流程

1. **信息收集**：提取标题、描述、环境、复现步骤、期望与实际结果
2. **问题分类**：Bug/缺陷、功能需求、配置问题、使用咨询、性能问题
3. **影响评估**：范围（单用户/多用户/全部）、紧急程度（紧急/高/中/低）
4. **历史相似提单查询**：读取 `ticket-analysis/experience-database.md`（311条记录）
5. **根因分析**：结合历史案例和技术文档分析
6. **解决方案建议**：针对性建议、临时规避方法、相关文档

### 常见问题类型速查

| 类型 | 常见原因 | 优先参考 |
|------|----------|---------|
| 性能问题 | 网控阻塞、临时表阻塞、反写阻塞 | 金蝶云社区-星空企业版 |
| 数据问题 | API误操作、并发归档问题 | 金蝶云社区-星空企业版 |
| 转换问题 | 组织隔离、事件时机错误 | 金蝶云社区-星空企业版 |
| 反写问题 | 并发提交、规则配置错误 | 金蝶云社区-星空企业版 |
| 代码开发 | 语法错误、逻辑问题 | Stack Overflow + GitHub |

### 外部参考资源

| 网站 | 用途 | 优先使用场景 |
|------|------|-------------|
| [金蝶云社区-星空企业版](https://vip.kingdee.com/link/index/t/1) | 官方知识库、技术文档、补丁下载 | 所有金蝶星空相关问题 |
| [金蝶在线帮助](https://help.kingdee.com) | 产品功能说明、操作手册 | 功能使用咨询 |
| [Stack Overflow](https://stackoverflow.com) | 编程技术问题 | 代码开发问题 |

---

## 模块二：BOS设计器与平台开发参考

### 资料导航

| 文档 | 内容聚焦 | 适用场景 |
|------|---------|---------|
| [bos-reference/reference.md](bos-reference/reference.md) | 表达式、校验规则、界面布局、数据库 | 开发配置、表达式编写 |
| [bos-reference/bos-platform-help.md](bos-reference/bos-platform-help.md) | 产品介绍、操作步骤、发布部署 | 平台使用、部署实施 |

### 核心概念速查

| 概念 | 用途 | 使用场景 |
|------|------|----------|
| **标识** | 控件标识，控制元数据界面显示 | 表达式/插件取数、控制可见性 |
| **字段名** | 数据库存储字段名 | SQL查询、创建视图 |
| **绑定实体属性** | 实体数据包属性名 | 插件取数 |

### 常用字段表达式速查

**文本**：不为空 `F_Text <> null and F_Text <> ""`，包含 `F_Text.find("值") >= 0`，切片 `F_Text[n:m]`，拆分 `F_Text.split("-")`

**日期**：不为空 `FDate <> null`，年月 `FDate.Year/.Month`，当前日期 `@currentshortdate`，加减 `FDate.AddDays(n)/AddMonths(n)`，间隔 `(FDate - FCreateDate).Days`

**基础资料**：内码 `FMaterialId.Id`，编码 `.FNumber`，名称 `.FName`，分组 `.FMaterialGroup.Number`。注意：第一层可取完整数据包，第二层只能取 Id/Number/Name

**基础资料引用的辅助资料属性**（如部门属性）：需先在BOS设计器"引用属性"中添加，再按内码比较：`FExpenseDeptID.FDeptProperty["Id"] = '辅助资料内码'`。获取内码方法：辅助资料列表过滤引出，序号即Id。⚠️ Id值因环境而异

**多选基础资料**：个数 `len(F_TPQJ_MulBase)`，编码 `map(lambda x:x.Number, F_TPQJ_MulBase)`，名称拼接 `"*".join(map(lambda x:x.Name.ToString(), F_TPQJ_MulBase))`

**弹性域**：`GETFLEXDETAILVALUE(维度字段标识, "子维度属性标识", 类型)`（1=编码，2=名称）

### Lambda 表达式速查

| 函数 | 示例 | 说明 |
|------|------|------|
| `filter` | `filter(lambda x:x.FNumber=="1.01", FEntity)` | 过滤 |
| `map` | `map(lambda x:x.FPrice, FEntity)` | 映射提取 |
| `sum` | `sum(map(lambda x:x.FQty, filter(...)))` | 合计 |
| `max/min` | `max(map(lambda x:x.FDate, FEntity))` | 最大/最小 |
| `len` | `len(F_TPQJ_MulBase)` | 计数 |
| `join` | `"+".join(map(lambda x:x.FName, FEntity))` | 拼接 |

> **注意**：Python 内置函数大小写敏感，`sum`/`min`/`max` 必须小写。

### BOS平台集成开发速查

**业务单据配置 19 步**：创建与设计(1-6) → 测试与预览(7-9) → 发布与部署(10-12) → 客户端配置(13-15) → 功能设置(16-19)

**权限控制 5 步**：创建权限对象 → 配置单据权限控制 → 发布权限项 → 分配功能权限 → 分配字段权限

**补充资料**：BOS知识地图 https://vip.kingdee.com/article/392699482837824512 | BOS设计器专题 https://vip.kingdee.com/knowledge/specialDetail/363716320510095360

---

## 模块三：用户角色与权限管理

### 适用场景

用户账号管理、角色配置、功能/数据/字段权限设置、权限问题排查、权限变更审计、数据规则计算排查、用户许可与登录问题。

### 用户管理

**菜单**：系统管理 → 用户管理 → 用户。创建方式：手动/引入/批量导入/AD域同步/第三方认证。

**用户状态**：禁用（暂停登录）、启用、锁定（密码错误超限）、删除（不可恢复）。

**密码策略**：系统管理 → 系统参数 → 安全策略。可配最小长度、复杂度、有效期、错误锁定次数等。

**忘记密码（V9.1）**：管理员重置、邮箱验证码找回、动态密码找回（云之家/企微/钉钉/飞书）。

### 角色管理

**分类**：系统管理员角色（子管理员，有授权范围限制）、普通角色、公有角色（仅administrator可维护）、私有角色（需指定组织）。

**预置角色**：全功能用户（全部功能操作权限）、全员角色（最小权限集）。

### 权限体系四大类

**功能权限**：控制可操作的功能/菜单。路径：系统管理 → 权限管理 → 功能权限。状态优先级：**禁止 > 有权 > 无权**。三种授权方式：按角色（推荐）、按用户、按组织。

**数据权限**：控制可见数据范围。路径：系统管理 → 权限管理 → 数据权限。类型：数据范围、基础资料权限、分组数据权限。前提是先有功能权限。

**字段权限**：控制字段可见/可编辑。路径：系统管理 → 权限管理 → 字段权限。默认**有权**，禁止优先。只能按组织控制，不能按条件控制。

**权限继承规则**：用户权限=所有角色权限并集（取最大）。功能权限禁止优先，数据权限交集合并（**跨组织生效**），字段权限并集。系统管理员不受限制。

### 权限问题排查七步法

1. 确认用户信息 → 2. 检查角色绑定 → 3. 检查功能权限 → 4. 检查数据权限 → 5. 检查字段权限 → 6. 检查组织权限 → 7. 查看权限日志

详细排查方案：[permission-management/reference-permission-troubleshoot.md](permission-management/reference-permission-troubleshoot.md)
提单问题总结：[permission-management/reference-ticket-issues-summary.md](permission-management/reference-ticket-issues-summary.md)
V9.1培训要点：[permission-management/reference-v91-training-guide.md](permission-management/reference-v91-training-guide.md)

### 常见问题速查

| 问题 | 原因 | 解决 |
|------|------|------|
| 无法登录 | 账号禁用/锁定/密码过期 | 检查用户状态 |
| 看不到菜单 | 未授功能权限 | 为角色添加功能权限 |
| 看不到数据 | 数据权限限制 | 调整数据权限条件 |
| 字段只读 | 字段权限不可编辑 | 修改字段权限 |
| 权限正确但仍无权 | 缓存未刷新 | 重新登录或清权限缓存 |
| 多组织列表无数据 | 跨组织数据权限交集冲突 | 排查所有组织下角色数据权限 |

---

## 模块四：业务流开发（单据转换/反写/业务流程）

### 适用场景

单据转换配置、下推/选单操作、转换插件和反写插件开发、业务流程设计与发布、上下查联查、反写规则配置、关联关系排查。

### 知识库结构

| 文件 | 用途 | 何时读取 |
|------|------|---------|
| [business-flow/knowledge-base.md](business-flow/knowledge-base.md) | 54 篇文章结构化摘要，含插件事件、API、配置要点 | **优先读取** |
| business-flow/articles/ | 150 篇原始文章全文，含完整代码示例 | 需要详细原文时按文件名读取 |

查找方式：先在 knowledge-base.md 找到"来源: `文件名.md`"，再到 articles/ 读取同名文件。

### 单据转换插件事件清单（完整）

**表单/列表插件事件**（选单页面和调用转换引擎之前）：
1. `OnShowConvertOpForm` → 2. `OnTargetBillChanged` → 3. `OnChangeConvertRuleEnumList` → 4. `OnGetConvertRuleEvent`

**下推事件**（16个，按触发顺序）：
`OnInitVariable` → `OnQueryBuilderParemeter` → `OnInSelectedRow` → `OnParseFilter` → `OnBeforeGetSourceData` → `OnGetSourceData` → `OnBeforeGroupBy` → `OnCreateTarget` → `OnBeforeFieldMapping` → `OnFieldMapping` → `OnAfterFieldMapping` → `OnCreateLink` → `OnAfterCreateLink` → `OnGetConvertBusinessService` → `OnAfterConvertBusinessService` → `AfterConvert`

**选单前事件**（3个）：`OnInitVariable` → `OnParseFilterOptions` → `OnParseFilter`
**选单后事件**（15个）：与下推类似但 `OnGetDrawSourceData` 替代 `OnGetSourceData`，`OnCreateDrawTarget` 替代 `OnCreateTarget`

### 反写插件事件清单（13个）

`BeforeTrackBusinessFlow` → `BeforeCreateArticulationRow` → `BeforeWriteBack` → `AfterCustomReadFields` → `RuleFirstRunning` → `AfterCommitAmount` → `BeforeCloseRow` → `AfterCloseRow` → `BeforeCheckHighLimit` → `AfterCheckHighLimit` → `BeforeSaveWriteBackData` → `AfterSaveWriteBackData` → `FinishWriteBack`

### 关键 API 和类

- 转换插件基类：`AbstractConvertPlugIn`（命名空间 `Kingdee.BOS.Core.Metadata.ConvertElement.PlugIn`）
- 反写插件基类：`AbstractBusinessFlowServicePlugIn`
- `ConvertServiceHelper.Push()` / `GetConvertRule()`
- `BusinessDataServiceHelper.Save()`
- `BusinessFlowServiceHelper.LoadTableDefine()`

### 关键数据库表

- 关联实例：`t_bf_instance` / `t_bf_instanceEntry` / `t_bf_instanceAmount`
- 反写快照：`t_bf_instanceSnap` / `t_bf_instanceSnapHis`
- 转换规则：`T_META_CONVERTRULE`；反写规则：`T_BF_WRITEBACKRULE`
- 流程定义：`T_BF_PROCDEF` / `T_BF_DEFVERSION`

### 关键 FormId

选单页面 `BOS_ConvertOpForm`、上下查 `BF_LookUPTracker`、全流程跟踪 `BOS_TrackResultForm`、批量生成 `BOS_ConvertResultForm`、流程设计 `BOS_BFDesigner`

---

## 模块五：BOS二次开发（编码规则/控件/表达式/插件）

### 适用场景

编码规则配置、UI控件用法、表达式与Python函数编写、值更新与实体服务规则、校验规则、过滤方案、执行计划、二次开发插件编写。

### 知识库结构

| 文件 | 用途 | 何时读取 |
|------|------|---------|
| [bos-development/knowledge-base.md](bos-development/knowledge-base.md) | 120 篇文章结构化摘要 | **优先读取** |
| bos-development/articles/ | 120 篇原始文章全文 | 需要详细原文时按文件名读取 |

### 八大插件类型

| 插件类型 | 基类 | 注册位置 |
|---------|------|---------|
| 表单插件 | `AbstractDynamicFormPlugIn` / `AbstractBillPlugIn` | 表单属性 → 表单插件 |
| 列表插件 | `AbstractListPlugIn` | 表单属性 → 列表插件 |
| 操作插件 | `AbstractOperationServicePlugIn` | 操作列表 → 编辑操作 → 服务插件 |
| 转换插件 | `AbstractConvertPlugIn` | BOS设计器 → 转换规则 → 插件策略 |
| 反写插件 | `AbstractBusinessFlowServicePlugIn` | 表单属性 → 单据关联配置 → 反写插件 |
| 账表取数 | `SysReportBaseService` | 账表属性 → 服务器插件 |
| 账表表单 | `AbstractSysReportPlugIn` | 账表属性 → 表单插件 |
| 元数据构建 | — | — |

### 单据状态值

Z(暂存)、A(创建)、B(审核中)、C(已审核)、D(重新审核)。数据库字段 `FDOCUMENTSTATUS`，类型 char(1)。

### 编码规则关键 API

- `BillCodeRuleService.GetBillNo()` — 根据编码规则生成编号
- `BusinessDataServiceHelper.GetBillNoByField()` — 为指定字段生成编号
- 编码规则表：`T_BAS_BILLCODERULE` / `T_BAS_BILLCODERULE_L`
- 自动补号：保存/删除失败异步触发，补号池按编码规则分表管理

---

## 回答规范

1. **引用来源**：回答时引用具体文章标题和出处，便于用户查阅原文
2. **代码示例**：提供具体 C#/Python 代码示例，包含类继承、命名空间、关键事件方法
3. **插件事件**：列出完整事件链和触发顺序，标注每个事件的可干预点
4. **配置指引**：给出分步操作路径，含 BOS 设计器中的具体菜单
5. **数据库排查**：给出相关表名和查询思路
6. **知识不足时**：建议使用 `kingdee-fetch` 技能从金蝶云社区抓取更多文章，或建议用户提供具体单据标识、报错信息以缩小排查范围
7. **版本信息**：涉及特定版本特性时注明版本号和补丁号（如 V9.0、PT-146939）

---

## 注意事项

- 分析提单前确认信息完整性，必要时请求补充
- 对于敏感信息注意脱敏处理
- 复杂问题建议拆分为多个子问题分析
- 保持分析客观性，避免主观臆断
- 优先参考经验数据库中的历史案例
- 数据修复操作前务必先备份
- 金蝶云社区包含多个产品线，本技能**仅参考"星空企业版"组织下的文章和知识**
