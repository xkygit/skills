---
title: 显示单据转换操作页面事件OnShowConvertOpForm
description: 
author: eris
tags: 二次开发方案, 快速入门
views: 4020
collections: 31
useful: 9
id: 167361162383311616
layer: 1
category: 单据转换
---

**作者**: eris | **浏览**: 4020 | **收藏**: 31 | **有用**: 9

**标签**: 二次开发方案, 快速入门

**事件**：显示单据转换操作页面事件，OnShowConvertOpForm

**所属插件**：表单插件，列表插件

**触发时机**：

1.下推，点击下推菜单，弹出选单页面之前触发

2.选单，点击选单菜单，弹出选单页面之前触发

3.上查，点击上查菜单，弹出联查页面之前触发

4.下查，点击下查菜单，弹出联查页面之前触发

**作用**：

1.对可选单据进行干预，过滤，排序，改名等

2.第三方选单或下推

3.限定下推时目标单据可选的组织

4.对下推的单据数据进行干预

**注意点**：

单据下推或选单，单据转换操作页显示的可选单据默认是按名称升序排序

此事件需要在表单和列表插件都实现

**示例**：单据A下推时，可选单据按名称倒序排序显示，并且过滤掉名称不含“单据”的单据。

没有插件干预情况下，单据A下推选单页面显示情况：

![](images/img_0100d3e0325fbee041e49c947982617247b0.png)

> **📸 图解操作流程**
>
> 1. [步骤1] 操作动作：查看，界面元素：金蝶云星空-单据A列表及下推选单弹窗，当前界面：金蝶云星空客户端-单据列表页面，备注：主界面为"单据A"的列表视图，显示了多条单据数据（BillA30913至BillA30866），每行包含单据编号、单据类型等字段。右侧弹出"单据转换操作界面"对话框，其中列出三个可选目标单据选项："单据A"（被选中，蓝色圆点）、"单据B"、"销售订单"。红色箭头和文字标注说明当前状态为"默认按名称升序显示"
> 2. [步骤2] 操作动作：查看，界面元素：参数选择区域，当前界面：单据转换操作界面-参数选择页签，备注：弹窗底部"参数选择"区域显示转换规则、单据类型、目标组织等参数配置项

 2. 插件代码，这里需要注意表单插件和列表插件都需要重载此事件

表单插件代码：

using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.ComponentModel;

using Kingdee.BOS.Util;

using Kingdee.BOS.Core.Bill.PlugIn;

using Kingdee.BOS.Core.List.PlugIn.Args;

using Kingdee.BOS.Core.Metadata.ConvertElement;

using Kingdee.BOS.Core.DynamicForm.PlugIn.Args;

using Kingdee.BOS.Core.DynamicForm;

namespace Kingdee.BOS.TestPlugIn

{

    [HotUpdate]

    [Description("单据A表单插件")]

    public class BillAFormPlugIn : AbstractBillPlugIn

    {

        /// 

        /// 下推时按名称倒序显示可选单据

        /// 

        /// 

        public override void OnShowConvertOpForm(ShowConvertOpFormEventArgs e)

        {

            //首先判定是什么操作触发此事件

            if (e.ConvertOperation == FormOperationEnum.Push)

            {

                var bills = e.BillList.Where(x => x.Name.ToString().Contains("单据"));

                e.BillList = bills.OrderByDescending(x => x.Name).ToList();

            }

        }

	}

列表插件代码：

```
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

using Kingdee.BOS.Util;
using Kingdee.BOS.Core.List.PlugIn;
using Kingdee.BOS.Core.List.PlugIn.Args;
using Kingdee.BOS.Core.DynamicForm;

namespace Kingdee.BOS.TestPlugIn
{
    [HotUpdate]
    [Description("单据A列表插件")]
    public class BillAListPlugIn : AbstractListPlugIn
    {
        public override void OnShowConvertOpForm(ShowConvertOpFormEventArgs e)
        {
            base.OnShowConvertOpForm(e);
            //首先判定是什么操作触发此事件
            if (e.ConvertOperation == FormOperationEnum.Push)
            {
                var bills = e.BillList.Where(x => x.Name.ToString().Contains("单据"));
                e.BillList = bills.OrderByDescending(x => x.Name).ToList();
            }
        }
```

[](app://yunDisk?groupId=XT-577f0277e4b086c4f14b17d7-XT-0060b6fb-b5e9-4764-a36d-e3be66276586&userId=XT-0060b6fb-b5e9-4764-a36d-e3be66276586)

 3. 注册插件

![](images/img_0100d23eb747c9bf4995aa21325ed5bc12e6.png)

> **📸 图解操作流程**
>
> 1. [步骤1] 操作动作：查看，界面元素：BOS IDE-表单属性面板，当前界面：BOS设计器-属性配置窗口，备注：右侧"属性"面板显示当前选中对象为"单据A__Bill"，列表中包含名称、标题、唯一键字段名等属性项。其中"表单插件"和"列表插件"两个属性行被红框标注，分别显示了已注册的插件类名（Kingdee.BOS.TestPlugIn.Rep... 和 Kingdee.BOS.TestPlugIn.BilA...）
> 2. [步骤2] 操作动作：点击/选择，界面元素：表单插件或列表插件属性值区域，当前界面：BOS IDE-属性面板，备注：在属性面板中点击"表单插件"或"列表插件"对应的值区域，打开插件注册对话框进行插件绑定操作

4. 插件干预后的显示效果：

![](images/img_0100c27932151ebe45809d3fd32ce57270d5.png)

> **📸 图解操作流程**
>
> 1. [步骤1] 操作动作：查看，界面元素：金蝶云星空-插件干预后的下推选单弹窗，当前界面：金蝶云星空客户端-单据列表页面，备注：主界面为"单据A"的列表视图，显示多条单据数据。右侧弹出"单据转换操作界面"对话框，与干预前不同的是：可选目标单据的排列顺序已变为倒序——"单据B"现在排在第一位并被选中（蓝色圆点），"单据A"排在第二位。这验证了插件代码中OrderByDescending排序逻辑生效
> 2. [步骤2] 操作动作：确认/查看，界面元素：参数选择区域，当前界面：单据转换操作界面-参数选择页签，备注：参数选择区显示转换规则为"转换规则z"，单据类型为"单据A类型1"，目标组织为"机加事业部"