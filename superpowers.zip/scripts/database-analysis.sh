#!/bin/bash

# Superpowers数据库分析脚本
# 使用Superpowers技能库进行数据库结构分析

echo "🚀 启动Superpowers数据库分析..."

# 第一步：建立数据库连接
echo "📡 第一步：建立数据库连接"
echo "命令：使用superpowers连接数据库，分析表结构"
echo "应用：架构设计技能进行数据库连接和分析"

# 第二步：表结构采集
echo "📊 第二步：表结构采集"
echo "命令：使用superpowers分析所有表的结构信息"
echo "包括：字段类型、约束、索引、外键关系"

# 第三步：业务表识别
echo "🏢 第三步：业务表识别和分类"
echo "命令：应用superpowers架构设计技能识别业务单据表"
echo "分类：单据表、基础数据表、关联表、系统表"

# 第四步：字段深度分析
echo "🔍 第四步：字段深度分析"
echo "命令：使用superpowers分析字段业务含义和数据规则"
echo "分析：主键、外键、索引字段、业务规则"

# 第五步：关联关系映射
echo "🔗 第五步：关联关系映射"
echo "命令：应用superpowers代码重构技能分析表间关系"
echo "输出：ER图、关联关系图、数据流向图"

# 第六步：业务逻辑还原
echo "🔄 第六步：业务逻辑还原"
echo "命令：使用superpowers架构设计技能还原业务流程"
echo "结果：业务流程图、数据生命周期、权限控制点"

# 第七步：生成分析文档
echo "📝 第七步：生成分析文档"
echo "命令：使用superpowers文档生成技能创建数据库分析报告"
echo "输出：数据字典、ER图、业务文档、优化建议"

echo ""
echo "✅ Superpowers数据库分析流程完成！"
echo ""
echo "🎯 可用命令示例："
echo "  \"使用superpowers分析数据库表结构\""
echo "  \"应用superpowers架构设计技能分析业务关系\""
echo "  \"使用superpowers文档生成技能创建数据字典\""
echo ""
echo "📁 输出文件："
echo "  - 数据字典.md（字段说明和约束）"
echo "  - ER关系图.png（实体关系图）"
echo "  - 业务流程分析.md（流程说明）"
echo "  - 优化建议.md（性能和设计改进）"