---
name: superpowers
summary: Claude Code超能力：核心技能库
author: richvieren
version: 1.0.0
description: |
  Superpowers是Claude Code的核心技能库，包含38个专业智能体、156项技能的超级系统。
  
  核心功能：
  - 测试驱动开发
  - 代码调试
  - 协作编程
  - 文档生成
  - 架构设计
  - 代码重构
  - 性能优化
  - 部署自动化
  - 数据库结构分析

usage: |
  Superpowers是一个"代理技能框架"，通过一系列可组合的技能实现完整的开发工作流。
  
  主要技能分类：
  - **开发技能**：编码、测试、调试
  - **数据库技能**：结构分析、表关系映射、业务流程还原
  - **协作技能**：代码审查、合并请求
  - **文档技能**：注释、文档生成
  - **架构技能**：设计模式、系统架构
  - **运维技能**：部署、监控、优化

installation: |
  1. 将此技能放入~/.workbuddy/skills/目录
  2. 重启Claude Code
  3. 根据需要调用具体技能

trigger_keywords: |
  superpowers
  超能力
  技能库
  开发框架
  编程工具
  AI助手
  数据库分析
  表结构
  字段分析
  关联关系
  单据分析
  数据字典
  ER图

examples: |
  # 使用superpowers技能
  "使用superpowers进行代码重构"
  "调用superpowers测试驱动开发"
  "应用superpowers架构设计"
  "使用superpowers分析数据库表结构"
  "应用superpowers进行数据库业务流程还原"
  "调用superpowers生成数据字典和ER图"

files:
  - "SKILL.md"
  - "README.md"
  - "skills/"
  - "examples/"
  - "guides/"
  - "scripts/"

dependencies: []
license: MIT
---