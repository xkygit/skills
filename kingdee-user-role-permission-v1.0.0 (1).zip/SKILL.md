---
name: kingdee-permission-management
description: "[user] 金蝶云星空用户角色与权限管理全面指南（含V9.1培训要点）。涵盖用户管理（创建/禁用/密码策略/锁定终端/忘记密码找回）、角色分类与配置（系统管理员角色/自定义角色/公有私有角色/角色属性）、权限体系（功能权限/数据权限/字段权限/特殊权限）的配置方法与注意事项、权限报表（按用户/按角色/字段权限报表）、子系统管理员授权模式（启用/停用/预置角色）、岗位汇报体系数据规则、基础资料数据直接授权、基础资料联动应用、数据权限控制到单据体、角色授权变更日志记录（二开方案，含权限快照SQL与前后对比实现）、权限问题的诊断与排查、上机操作日志（归档/清理/性能看板）、以及高频提单问题总结（数据规则计算逻辑/岗位体系数据规则/基础资料联动应用/用户许可与登录/密码策略/许可管理/多应用服务器缓存/提单排查思路）。当用户提到用户管理、角色配置、权限授权、功能权限、数据权限、字段权限、权限问题、无权限、权限诊断、权限排查、用户角色、权限设置、权限变更日志、授权审计、权限快照对比、数据规则、岗位体系、用户许可、许可管理、登录问题、密码过期、超时退出、缓存问题、提单排查、批量授权、字段批量授权、权限报表、子系统管理员、基础资料直接授权、上机操作日志、日志归档、锁定终端、忘记密码、禁止权限时使用此技能。"
---

# 金蝶云星空用户角色与权限管理

## 使用场景

当用户遇到以下情况时应用此技能：
- 创建或管理用户账号
- 配置角色和权限
- 排查"无权限"或权限相关问题
- 设置数据权限或字段权限
- 用户无法访问某功能或数据
- 需要记录角色授权变更日志（审计追溯）
- 需要通过二开实现权限变更前后对比
- 排查数据规则计算逻辑（单角色/多角色/明细数据规则/岗位体系）
- 基础资料联动应用查不出数据
- 用户许可与登录问题（多数据中心登录/密码过期/超时退出/许可丢失）
- 多应用服务器权限缓存不一致
- 提单问题诊断与排查思路
- 功能权限的禁止/有权/无权优先级与合并规则
- 批量授权与字段批量授权
- 权限报表查询（按用户/按角色/字段权限报表）
- 子系统管理员授权模式的启用与停用
- 基础资料数据直接授权（物料/客户/供应商/仓库）
- 数据权限控制到单据体
- 岗位汇报体系数据规则配置
- 上机操作日志管理（归档/清理/性能看板）
- 用户锁定终端与忘记密码找回

## 一、用户管理

### 1.1 用户创建

**菜单路径**：【系统管理】→【用户管理】→【用户】

**创建方式**：
- 手动创建：直接在用户管理界面新增
- 引入：通过模板引入
- 数据引入工具：使用数据引入工具批量导入
- AD域同步：与 Active Directory 集成自动同步
- 第三方认证同步：通过 SSO/OAuth 等集成
- 组织人员自动生成：从 HR 人员信息自动创建

**用户关键属性**：
- 用户账号（登录名，唯一标识，不可取消唯一性）
- 用户名称（显示名称，唯一，不可取消唯一性）
- 所属组织（默认登录组织）
- 认证方式（密码/AD域/第三方）
- 用户状态（正常/禁用/锁定）
- 用户分组
- 对应的员工联系对象
- 许可分组
- 域用户名称

### 1.2 用户状态管理

| 操作 | 说明 | 恢复方式 |
|------|------|---------|
| 禁用 | 暂停用户登录，保留数据。禁用用户执行同步用户时自动释放注册站点 | 管理员手动启用 |
| 启用 | 恢复已禁用的用户 | - |
| 锁定 | 密码错误超限后自动锁定 | 等待超时或管理员解锁 |
| 删除 | 永久删除用户（谨慎操作） | 不可恢复 |

### 1.3 密码策略

**配置路径**：【系统管理】→【系统参数】→【安全策略】

可配置项：密码最小长度（默认8位）、复杂度要求（数字+字符+字母，默认全勾选）、密码有效期（时效规则）、密码错误锁定次数（控制规则）、锁定时长、历史密码重复限制、首次登录强制修改密码、默认密码设置。

**重置密码**：对单一用户重置登录密码，并解锁用户。

**强制修改密码**：强制所选用户必须修改密码。

**忘记密码找回**（V9.1）：三种方式——管理员重置密码、邮箱验证码找回（需配置邮件发送服务器）、动态密码找回（支持云之家/企业微信/钉钉/飞书/金蝶云App）。

**锁定终端**：针对需要对用户指定机器登录系统提供锁定终端功能，支持GUI客户端以及IE内核浏览器（非IE需安装金蝶本地服务）。

---

## 二、角色管理

### 2.1 角色分类

**按类型分**：
- **系统管理员角色（子管理员）**：可设置授权范围，业务对象功能授权只能在该设置范围内对角色授权
- **普通角色**：可进行授权和查询权限

**按属性分**（前提：启用多组织）：
- **公有角色**：只有administrator可以创建和维护，子管理员均可使用，系统预置角色均为公有
- **私有角色**：需指定所属组织，所属组织下的用户才可以使用，administrator和子管理员都可维护

**预置角色**：
- 全功能用户：拥有所有业务功能的操作权限
- 全员角色：所有用户默认拥有的最小权限集

### 2.2 角色操作

**菜单路径**：【系统管理】→【用户管理】→【角色】

**创建角色**：
1. 点击【新增】
2. 输入角色编码、名称
3. 选择角色属性（公有/私有）
4. 设置角色描述
5. 保存

**角色与用户绑定**：
- 方式一：在用户编辑界面 →【角色】页签 → 添加角色
- 方式二：在角色编辑界面 →【用户】页签 → 添加用户
- 方式三：批量授权 → 选多个用户同时赋予角色

**角色操作**：复制角色（基于现有角色快速创建）、修改角色权限、禁用/删除角色。

**角色扩展应用**：工作流/审批流的节点参与人可以选择角色；业务监控方案的接收人可以选择角色。

---

## 三、权限体系

金蝶云星空的权限体系分为四大类：

### 3.1 功能权限

控制用户可以操作哪些功能（菜单、按钮）。

**配置路径**：【系统管理】→【权限管理】→【功能权限】

**权限状态**：有权、无权、禁止。默认为**无权**。优先级：**禁止 > 有权 > 无权**。

**授权粒度**：
- 粗放型：子系统功能授权（子系统 + 权限组）
- 精细型：业务对象功能授权（业务对象 + 具体权限）

**授权原则**：【查看】权限作为全部权限的**前置权限**。

**授权步骤**：
1. 选择角色
2. 选择业务对象（如"销售订单"）
3. 勾选允许的操作权限：新增、查看、修改、删除、审核、反审核、提交、打印等
4. 保存权限方案

**三种授权方式**：
- 按角色授权：为角色统一配置权限（推荐）
- 按用户授权：直接为特定用户配置权限
- 按组织授权：按组织维度批量授权

**批量授权**：由粗到细方式提供，采用**覆盖模式**，不携带所选角色的权限内容。

**业务验权原则**：用户 + 当前登录组织 + 角色（合集），按照单一对象控制。业务单据新增时，使用的基础资料F8**不验其自身查看权限**。

**权限状态合并规则**：禁止+有权=禁止、有权+无权=有权、禁止+无权=禁止。

### 3.2 数据权限

控制用户可以看到/操作哪些数据范围。解决"可以做多少事情"的问题。

**配置路径**：【系统管理】→【权限管理】→【数据权限】

**前提**：功能权限（先有功能权限，再配数据权限）。

**数据权限的功能权限项**：查看、修改、删除、审核、反审核。

**数据权限类型**：
- **数据范围**：限制用户可访问的单据范围（如只能看本部门的销售订单）。数据规则中所选业务对象的单据头字段均可作为条件
- **基础资料权限**：限制用户可选择的基础资料范围（如只能选特定客户分类），位于业务单据的【基础资料权限】页签
- **分组数据权限**：按基础资料分组控制（如按物料分类控制）

**配置步骤**：
1. 选择角色
2. 选择业务对象
3. 设置数据范围条件（如：销售组织 = 当前用户所属组织）
4. 保存

**基础资料联动应用**：通过数据规则选项参数控制，启用后业务单据也按照基础资料范围控制。支持设置受控基础资料及关联业务单据对应受控字段。单据上存在多个基础资料则需要**同时有权限**才能查看。

**基础资料数据直接授权**：在基础资料列表页面直接选择需要授权的基础资料，授权给相关员工。目前支持：物料、供应商、客户、仓库。

**数据权限控制到单据体**：启用后可设置明细数据规则，只支持单个单据体（关键单据体），设置后单据列表和选单只能看到/选到有权限的单据体。

**存在无权明细行不允许打开单据**：数据规则选项参数控制，适用于信息严控企业。

**变量应用**：数据规则中使用变量可减少规则设置工作量。同一业务对象的数据范围可批量应用于其他角色及其他权限。

**岗位汇报体系数据规则**：启用后根据岗位+汇报类型形成岗位汇报体系，提供直接下属/所有下属、其他人员、所属部门/所有下级部门、其他部门、数据范围等设置，**只对业务单据的查看权限有效**。

### 3.3 字段权限

控制字段的可见性和可编辑性。

**配置路径**：【系统管理】→【权限管理】→【字段权限】

**权限内容**：区分查看/编辑，权限值为有权、无权、禁止。**字段权限默认是有权**。**禁止权限优先**。

**字段批量授权**：可设置批量授权字段，选择角色后对单个或多个业务对象批量设置敏感类字段（如金额、单价、数量、折扣率、折扣额）为无权或禁止。

**合并规则**：当用户属于多个角色时，字段权限取"最大权限"（即任一角色允许编辑，则用户可编辑）。

**注意事项**：
- 字段权限默认是有权，且跟功能权限**没有**关联关系
- 字段权限只能按照**组织**进行控制，**不能按条件**控制
- 禁止权限优先，如果要控制没有字段权限，要设置禁止权限
- 即使没有功能权限，也会默认有全部字段权限

### 3.4 权限报表

**按用户查看**：用户子系统权限报表、用户业务对象权限报表、用户字段权限报表——了解用户有哪些权限，由哪个角色带来，角色归属哪个组织。

**按角色查看**：角色子系统权限报表、角色业务对象权限报表、角色字段权限报表。

**用户权限报表**：按用户查询权限全貌，包括功能权限、数据权限、岗位数据规则、字段权限，可链接打开对应权限设置。

**用户业务对象字段权限报表**：通过用户、业务对象和组织机构快捷过滤，支持显示有权和无权字段。

### 3.5 特殊权限

- **审批流权限**：控制审批节点的审批人
- **打印权限**：控制打印模板的使用权限
- **报表权限**：控制报表的查看和导出权限

---

## 四、权限继承与覆盖规则

1. 用户的最终权限 = 所有角色权限的并集（取最大权限）
2. 用户级别的权限配置 > 角色级别的权限配置
3. 功能权限中禁止权限优先：禁止+有权=禁止、有权+无权=有权、禁止+无权=禁止
4. 数据权限采用交集模式（所有条件都要满足）
5. 数据权限的联动应用只对业务单据新增时有效
6. 字段权限采用并集模式（取最大权限），字段权限默认有权且跟功能权限无关联
7. 系统管理员角色不受权限限制
8. 功能权限控制是单一对象
9. 同一单据存在多个基础资料，则需同时满足权限范围才能查看

**重要提示：数据权限的交集合并是跨组织生效的**。用户在所有组织下所有角色的数据权限条件会同时参与交集计算，任何一个组织下角色的数据权限条件都可能影响其他组织的数据可见性。多组织环境下排查数据权限问题时，必须检查用户在**所有组织**下的角色及其数据权限配置，不能仅关注当前组织。此外，角色删除或权限变更后，权限缓存可能不会立即刷新，需主动清除缓存（路径：【系统管理】→【缓存管理】→ 清除权限缓存）并要求用户重新登录。详见排查文档案例6。

---

## 五、角色授权变更日志记录（二开方案）

### 5.1 业务场景

标准产品的权限报表仅能查看角色当前的"有权/无权"状态，无法追溯历史变更记录。在审计合规场景下，客户需要知道"谁在什么时间对哪个角色做了什么权限变更"。该需求需通过二次开发实现。

### 5.2 实现思路

核心思路是**授权前后快照对比**：

1. **授权前**：通过 SQL 查询当前角色的完整权限快照，保存为"授权前基线"
2. **执行授权**：用户在功能权限界面正常进行授权操作
3. **授权后**：再次执行同一 SQL 查询权限快照，保存为"授权后状态"
4. **差异比对**：将两次快照进行逐行比对，找出新增、删除、变更的权限项
5. **写入日志**：将差异记录写入自定义日志表，包含时间戳、操作人、角色、变更详情

### 5.3 权限相关核心表结构

| 表名 | 说明 | 关键字段 |
|------|------|---------|
| T_SEC_ROLE | 角色主表 | FROLEID（角色ID） |
| T_SEC_FUNCPERMISSION | 功能权限表（角色-业务对象映射） | FITEMID, FROLEID, FOBJECTTYPEID（业务对象ID） |
| T_SEC_FUNCPERMISSIONENTRY | 功能权限明细表（权限项与状态） | FITEMID, FPERMISSIONITEMID（权限项ID）, FPERMISSIONSTATUS（权限状态）, FDATARULE（数据规则） |
| T_SEC_FUNCPERBASEDATARULEENTRY | 基础资料数据规则明细表 | FITEMID, FBASEDATAOBJECTTYPEID（基础资料对象类型ID）, FDATARULEID（数据规则ID） |

**关键字段说明**：

- `FPERMISSIONITEMID`：权限项标识，对应具体操作（如新增、查看、修改、删除、审核等）
- `FPERMISSIONSTATUS`：权限状态值，表示该权限项是否被授权
- `FDATARULE`：数据规则，控制数据范围的过滤条件
- `FOBJECTTYPEID`：业务对象类型标识，对应具体的单据或功能（如销售订单、采购订单等）

### 5.4 权限快照查询 SQL

以下 SQL 用于查询指定角色的完整功能权限快照，在授权前后各执行一次以获取对比数据：

```sql
SELECT
    a.FROLEID,
    b.FOBJECTTYPEID,
    c.FPERMISSIONITEMID,
    c.FPERMISSIONSTATUS,
    c.FDATARULE,
    d.FBASEDATAOBJECTTYPEID,
    d.FDATARULEID
FROM T_SEC_ROLE a
LEFT JOIN T_SEC_FUNCPERMISSION b ON a.FROLEID = b.FROLEID
LEFT JOIN T_SEC_FUNCPERMISSIONENTRY c ON b.FITEMID = c.FITEMID
LEFT JOIN T_SEC_FUNCPERBASEDATARULEENTRY d ON d.FITEMID = b.FITEMID
WHERE a.FROLEID = @RoleId  -- 替换为实际的角色ID
```

**使用方式**：

- 在执行授权操作之前，运行此 SQL 将结果保存到临时表或变量中（授权前快照）
- 授权操作完成后，再次运行此 SQL 获取最新结果（授权后快照）
- 对比两次结果集的差异，即为本次授权的变更内容

### 5.5 二开实现方案

#### 方案一：数据库层面实现（推荐用于简单场景）

**步骤**：

1. **创建自定义日志表**：用于记录权限变更历史

```sql
CREATE TABLE T_SEC_PERMISSION_CHANGELOG (
    FID BIGINT IDENTITY(1,1) PRIMARY KEY,
    FROLEID BIGINT NOT NULL,             -- 角色ID
    FOBJECTTYPEID NVARCHAR(200),         -- 业务对象ID
    FPERMISSIONITEMID NVARCHAR(200),      -- 权限项ID
    FOLD_STATUS NVARCHAR(50),            -- 变更前状态
    FNEW_STATUS NVARCHAR(50),            -- 变更后状态
    FOLD_DATARULE NVARCHAR(500),         -- 变更前数据规则
    FNEW_DATARULE NVARCHAR(500),         -- 变更后数据规则
    FCHANGETYPE NVARCHAR(20),            -- 变更类型：ADD/DELETE/MODIFY
    FOPERATOR NVARCHAR(100),             -- 操作人
    FOPERATETIME DATETIME DEFAULT GETDATE(), -- 操作时间
    FREMARK NVARCHAR(500)                -- 备注
);
```

2. **授权前执行快照保存**：将当前权限数据存入临时表

```sql
SELECT
    a.FROLEID,
    b.FOBJECTTYPEID,
    c.FPERMISSIONITEMID,
    c.FPERMISSIONSTATUS,
    c.FDATARULE,
    d.FBASEDATAOBJECTTYPEID,
    d.FDATARULEID
INTO #TempPermBefore
FROM T_SEC_ROLE a
LEFT JOIN T_SEC_FUNCPERMISSION b ON a.FROLEID = b.FROLEID
LEFT JOIN T_SEC_FUNCPERMISSIONENTRY c ON b.FITEMID = c.FITEMID
LEFT JOIN T_SEC_FUNCPERBASEDATARULEENTRY d ON d.FITEMID = b.FITEMID
WHERE a.FROLEID = @RoleId;
```

3. **授权后对比并写入日志**：

```sql
-- 授权后快照
SELECT
    a.FROLEID,
    b.FOBJECTTYPEID,
    c.FPERMISSIONITEMID,
    c.FPERMISSIONSTATUS,
    c.FDATARULE,
    d.FBASEDATAOBJECTTYPEID,
    d.FDATARULEID
INTO #TempPermAfter
FROM T_SEC_ROLE a
LEFT JOIN T_SEC_FUNCPERMISSION b ON a.FROLEID = b.FROLEID
LEFT JOIN T_SEC_FUNCPERMISSIONENTRY c ON b.FITEMID = c.FITEMID
LEFT JOIN T_SEC_FUNCPERBASEDATARULEENTRY d ON d.FITEMID = b.FITEMID
WHERE a.FROLEID = @RoleId;

-- 记录新增的权限（授权后有，授权前无）
INSERT INTO T_SEC_PERMISSION_CHANGELOG
    (FROLEID, FOBJECTTYPEID, FPERMISSIONITEMID, FOLD_STATUS, FNEW_STATUS, FCHANGETYPE, FOPERATOR)
SELECT
    af.FROLEID, af.FOBJECTTYPEID, af.FPERMISSIONITEMID,
    NULL, af.FPERMISSIONSTATUS, 'ADD', @Operator
FROM #TempPermAfter af
LEFT JOIN #TempPermBefore bf
    ON af.FROLEID = bf.FROLEID
    AND ISNULL(af.FOBJECTTYPEID,'') = ISNULL(bf.FOBJECTTYPEID,'')
    AND ISNULL(af.FPERMISSIONITEMID,'') = ISNULL(bf.FPERMISSIONITEMID,'')
WHERE bf.FROLEID IS NULL;

-- 记录删除的权限（授权前有，授权后无）
INSERT INTO T_SEC_PERMISSION_CHANGELOG
    (FROLEID, FOBJECTTYPEID, FPERMISSIONITEMID, FOLD_STATUS, FNEW_STATUS, FCHANGETYPE, FOPERATOR)
SELECT
    bf.FROLEID, bf.FOBJECTTYPEID, bf.FPERMISSIONITEMID,
    bf.FPERMISSIONSTATUS, NULL, 'DELETE', @Operator
FROM #TempPermBefore bf
LEFT JOIN #TempPermAfter af
    ON bf.FROLEID = af.FROLEID
    AND ISNULL(bf.FOBJECTTYPEID,'') = ISNULL(af.FOBJECTTYPEID,'')
    AND ISNULL(bf.FPERMISSIONITEMID,'') = ISNULL(af.FPERMISSIONITEMID,'')
WHERE af.FROLEID IS NULL;

-- 记录变更的权限（状态或数据规则发生变化）
INSERT INTO T_SEC_PERMISSION_CHANGELOG
    (FROLEID, FOBJECTTYPEID, FPERMISSIONITEMID, FOLD_STATUS, FNEW_STATUS, FOLD_DATARULE, FNEW_DATARULE, FCHANGETYPE, FOPERATOR)
SELECT
    af.FROLEID, af.FOBJECTTYPEID, af.FPERMISSIONITEMID,
    bf.FPERMISSIONSTATUS, af.FPERMISSIONSTATUS,
    bf.FDATARULE, af.FDATARULE,
    'MODIFY', @Operator
FROM #TempPermAfter af
INNER JOIN #TempPermBefore bf
    ON af.FROLEID = bf.FROLEID
    AND ISNULL(af.FOBJECTTYPEID,'') = ISNULL(bf.FOBJECTTYPEID,'')
    AND ISNULL(af.FPERMISSIONITEMID,'') = ISNULL(bf.FPERMISSIONITEMID,'')
WHERE ISNULL(af.FPERMISSIONSTATUS,'') <> ISNULL(bf.FPERMISSIONSTATUS,'')
   OR ISNULL(af.FDATARULE,'') <> ISNULL(bf.FDATARULE,'');

-- 清理临时表
DROP TABLE #TempPermBefore;
DROP TABLE #TempPermAfter;
```

#### 方案二：插件层面实现（推荐用于生产环境）

通过二开插件在权限保存事件中自动拦截并记录变更，无需手动执行 SQL。

**实现要点**：

1. **开发权限保存插件**：在功能权限保存操作的 `BeforeDoOperation` 和 `AfterDoOperation` 事件中分别获取权限快照
2. **BeforeDoOperation**：读取当前数据库中的权限数据作为"变更前"基线
3. **AfterDoOperation**：读取保存后的权限数据作为"变更后"状态，与基线对比后写入日志表
4. **记录关键信息**：操作时间、操作人（从当前会话获取）、角色ID、业务对象、权限项、变更前后状态、变更类型（新增/删除/修改）

**注意事项**：

- 插件中使用上述 5.4 节的 SQL 进行快照查询
- 建议在 `BeforeDoOperation` 中将快照数据缓存到插件上下文变量中，供 `AfterDoOperation` 对比使用
- 日志表建议增加索引（FROLEID、FOPERATETIME）以提升查询性能
- 生产环境中应注意大批量授权场景下的性能影响，建议异步写入日志

### 5.6 日志查询示例

**查询某角色的权限变更历史**：

```sql
SELECT
    cl.FOPERATETIME AS 操作时间,
    cl.FOPERATOR AS 操作人,
    r.FNAME AS 角色名称,
    cl.FOBJECTTYPEID AS 业务对象,
    cl.FPERMISSIONITEMID AS 权限项,
    cl.FCHANGETYPE AS 变更类型,
    cl.FOLD_STATUS AS 变更前状态,
    cl.FNEW_STATUS AS 变更后状态,
    cl.FREMARK AS 备注
FROM T_SEC_PERMISSION_CHANGELOG cl
LEFT JOIN T_SEC_ROLE r ON cl.FROLEID = r.FROLEID
WHERE cl.FROLEID = @RoleId
ORDER BY cl.FOPERATETIME DESC;
```

**查询指定时间段内所有权限变更**：

```sql
SELECT
    cl.FOPERATETIME AS 操作时间,
    cl.FOPERATOR AS 操作人,
    r.FNAME AS 角色名称,
    cl.FOBJECTTYPEID AS 业务对象,
    cl.FPERMISSIONITEMID AS 权限项,
    cl.FCHANGETYPE AS 变更类型,
    cl.FOLD_STATUS AS 变更前状态,
    cl.FNEW_STATUS AS 变更后状态
FROM T_SEC_PERMISSION_CHANGELOG cl
LEFT JOIN T_SEC_ROLE r ON cl.FROLEID = r.FROLEID
WHERE cl.FOPERATETIME BETWEEN @StartDate AND @EndDate
ORDER BY cl.FOPERATETIME DESC;
```

---

## 六、权限问题排查

### 6.1 标准排查七步法

详细排查方案请参阅 [reference-permission-troubleshoot.md](reference-permission-troubleshoot.md)。
高频提单问题总结请参阅 [reference-ticket-issues-summary.md](reference-ticket-issues-summary.md)。

**快速排查步骤**：

1. **确认用户信息** → 用户账号、所属组织、用户状态
2. **检查角色绑定** → 用户是否绑定了正确的角色
3. **检查功能权限** → 角色是否授予了对应的功能操作权
4. **检查数据权限** → 数据权限条件是否过滤了目标数据
5. **检查字段权限** → 字段是否被隐藏或设为只读
6. **检查组织权限** → 用户是否被授权到当前组织
7. **查看权限日志** → 通过日志确认具体拦截原因

### 6.2 常见问题速查

| 问题 | 可能原因 | 解决方案 |
|------|---------|---------|
| 用户无法登录 | 账号禁用/锁定/密码过期 | 检查用户状态，解锁或重置密码 |
| 看不到菜单 | 未授予功能权限 | 为角色添加对应菜单的功能权限 |
| 能看到菜单但无法操作 | 功能权限中未勾选操作项 | 补充勾选需要的操作权限 |
| 能操作但看不到数据 | 数据权限限制了范围 | 检查并调整数据权限条件 |
| 字段显示为只读 | 字段权限设置为不可编辑 | 修改字段权限为可编辑 |
| 权限设置正确但仍无权限 | 缓存未刷新 | 用户重新登录或清除权限缓存 |
| 多组织用户单据列表无数据（同角色他人正常） | 跨组织角色数据权限交集冲突，或已删除角色的权限缓存残留 | 先清缓存+重新登录验证；若仍异常则排查所有组织下角色的数据权限条件，消除交集矛盾（详见案例6） |
| 基础资料授权后不立即生效 | 权限缓存未刷新 | administrator缓存管理清除缓存，或重新保存用户 |
| 岗位体系角色和普通角色同时设置数据规则，权限不生效 | 员工任岗信息异常、未绑定员工 | 检查员工和任岗信息是否正确，是否被禁用（详见提单总结） |
| 基础资料联动应用查不出数据 | 使用主码fmasterid，仅用使用组织 | 给创建组织授权，或检查fmasterid引用方式 |
| 主业务组织F8弹窗内容为空 | 组织未给新增权限项或权限对象未绑定bos_new | 补充新增权限项，绑定bos_new |
| 多应用服务器权限缓存不一致 | 各站点缓存未同步 | common.config添加IsNoticeUpdateCache=true |
| 用户密码过期无法登录 | 密码有效期过期 | 通过SSO绕开或SQL更新密码过期时间 |
| 用户许可经常性丢失 | WebAPI保存用户/员工信息同步 | 排查是否有调WebAPI保存用户、保存员工操作 |

---

## 七、关键菜单路径速查

| 功能 | 菜单路径 |
|------|---------|
| 用户管理 | 系统管理 → 用户管理 → 用户 |
| 角色管理 | 系统管理 → 用户管理 → 角色 |
| 功能权限 | 系统管理 → 权限管理 → 功能权限 |
| 数据权限 | 系统管理 → 权限管理 → 数据权限 |
| 字段权限 | 系统管理 → 权限管理 → 字段权限 |
| 权限方案 | 系统管理 → 权限管理 → 权限方案 |
| 安全策略 | 系统管理 → 系统参数 → 安全策略 |
| 权限日志 | 系统管理 → 日志管理 → 权限日志 |
| 批量授权 | 系统管理 → 权限管理 → 批量授权 |
| 上机操作日志 | 系统管理 → 日志管理 → 上机操作日志 |

## 七A、子系统管理员授权模式

**启用路径**：启用子系统管理员功能授权模式后，可对子系统管理员角色进行功能授权。

**核心价值**：有效规避系统管理员拥有过大权利带来高风险，子系统管理员按权限设置进行精细管理。

**启用后变化**：
- 新增预置角色：安全保密员和安全审计员角色及其权限
- 原有 administrator 角色及权限保留，建议评估并调整
- 原有子系统管理角色的系统管理权限不再保留，需根据实际应用重新定义

**停用说明**：支持停用后还原原有授权模式。停用后预置角色和自定义子系统管理角色的系统管理权限全部还原，不再允许对子系统管理员角色进行功能授权。

## 七B、上机操作日志

**基本功能**：记录用户操作金蝶云星空系统的情况，按时间降序记录操作用户、具体业务、操作描述、IP地址等。

**日志归档**：
- **归档到备份表**：将操作日志移到备份表，减少当前查询量，可设置条数，系统自动处理
- **归档到日志库**：将操作日志从备份表移到日志库，减少业务库容量，支持定时自动处理
- **日志清理**：将上机日志从业务库备份表移除，备份到文件服务器或本地目录（启用后不可逆）

**性能看板**：对上机操作日志操作耗时进行统计分析，提供业务操作耗时变动分析和耗时排名分析。

详细培训要点请参阅 [reference-v91-training-guide.md](reference-v91-training-guide.md)。

## 八、参考资源

- 权限问题详细排查：[reference-permission-troubleshoot.md](reference-permission-troubleshoot.md)
- 提单问题总结（权限、用户许可）：[reference-ticket-issues-summary.md](reference-ticket-issues-summary.md)
- V9.1 系统管理产品培训要点：[reference-v91-training-guide.md](reference-v91-training-guide.md)
- 金蝶社区：[用户角色](https://vip.kingdee.com/knowledge/specialDetail/466599199069675776)
- 权限管理专题：[权限管理](https://vip.kingdee.com/knowledge/specialDetail/347379322266709248?productLineId=1)
- 权限问题汇总：[权限应用问题](https://vip.kingdee.com/knowledge/specialDetail/479289771085523712)
- 角色授权日志二开方案：[功能权限表结构参考](https://vip.kingdee.com/questions/549278431461229824?productLineId=1&lang=zh-CN)
